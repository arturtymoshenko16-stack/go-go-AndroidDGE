# FileHub Arctic Fox - Fixed 2

This project uses:
- Android Gradle Plugin 7.0.4
- Gradle 7.0.2 (downloaded explicitly by the workflow)
- JDK 11
- Android SDK 30 / Build Tools 30.0.3

Important: replace the previous workflow file in `.github/workflows/` with this one. Delete any other old workflow that still runs `gradle/actions/setup-gradle@v4`, searches for `settings.gradle.kts`, or uses Gradle 8.x. Otherwise GitHub may run the old workflow instead.

Upload the contents of this ZIP to the repository root, then run Actions > Build FileHub APK. Download `FileHub-ArcticFox-debug` from Artifacts.

This builds the sample FileHub APK in GitHub Actions. It does not yet build arbitrary Android project ZIPs directly on the tablet.
