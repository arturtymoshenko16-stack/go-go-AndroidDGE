# FileHub Arctic Fox - fixed project

This version uses Kotlin DSL files (`settings.gradle.kts`, `build.gradle.kts`) and a workflow that builds from the repository root. It deliberately does not search for or unpack another project ZIP.

Toolchain:
- Android Gradle Plugin 7.0.4 (Arctic Fox era)
- Gradle 7.0.2
- JDK 11
- Android SDK 30
- Build Tools 30.0.3

## GitHub
Upload the CONTENTS of this ZIP to the repository root, replacing the old project files and old workflow. Do not upload this ZIP inside another ZIP or leave an older workflow that still runs `Find project folder`.

Then open Actions and run `Build FileHub APK`. Download the `FileHub-ArcticFox-debug` artifact from the successful run.

This starter project builds the sample FileHub app. It does not yet compile arbitrary Android project ZIP files directly on the tablet.
