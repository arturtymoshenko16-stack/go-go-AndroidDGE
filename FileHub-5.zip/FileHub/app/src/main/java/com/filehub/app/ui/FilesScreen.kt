@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.filehub.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.FileTypes
import com.filehub.app.data.formatDate
import com.filehub.app.data.formatSize
import com.filehub.app.util.FileActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Универсальный список файлов: обзор папки (dir != null), категория, крупные файлы.
 * Долгое нажатие включает режим выделения, кнопка ⋮ в строке открывает меню действий.
 */
@Composable
fun FilesScreen(
    vm: MainViewModel,
    title: String,
    subtitle: String? = null,
    dir: File? = null,
    loader: suspend () -> List<File>
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    var files by remember { mutableStateOf<List<File>?>(null) }
    val selected = remember { mutableStateListOf<File>() }
    val selecting = selected.isNotEmpty()

    var menuTarget by remember { mutableStateOf<File?>(null) }
    var deleteTargets by remember { mutableStateOf<List<File>?>(null) }
    var renameTarget by remember { mutableStateOf<File?>(null) }
    var propsTarget by remember { mutableStateOf<File?>(null) }
    var showNewFolder by remember { mutableStateOf(false) }
    var showViewSheet by remember { mutableStateOf(false) }
    var showSelSheet by remember { mutableStateOf(false) }

    LaunchedEffect(vm.tick, vm.sort, vm.showHidden, vm.scan) {
        files = withContext(Dispatchers.IO) { loader() }
        selected.removeAll { !it.exists() }
    }

    BackHandler(enabled = selecting) { selected.clear() }

    fun toggle(f: File) {
        if (selected.contains(f)) selected.remove(f) else selected.add(f)
    }

    val selectedSize = remember(selected.size) {
        selected.sumOf { if (it.isFile) it.length() else 0L }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            if (selecting) {
                SimpleTopBar(
                    title = "Выбрано: ${selected.size}",
                    subtitle = formatSize(selectedSize),
                    onBack = { selected.clear() },
                    navIcon = Icons.Default.Close,
                    actions = {
                        IconButton(onClick = { FileActions.share(ctx, selected.toList()) }) {
                            Icon(Icons.Default.Share, contentDescription = "Отправить")
                        }
                        IconButton(onClick = { deleteTargets = selected.toList() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Удалить")
                        }
                        IconButton(onClick = { showSelSheet = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Ещё")
                        }
                    }
                )
            } else {
                SimpleTopBar(
                    title = title,
                    subtitle = subtitle,
                    onBack = { vm.back() },
                    actions = {
                        if (dir != null) {
                            IconButton(onClick = { showViewSheet = true }) {
                                Icon(Icons.Default.Tune, contentDescription = "Вид")
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (dir != null && vm.clipboard.isNotEmpty()) {
                Surface(color = cs.surface, tonalElevation = 3.dp) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            (if (vm.clipboardMove) "Переместить: " else "Копировать: ") +
                                vm.clipboard.size,
                            color = cs.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { vm.clearClipboard() }) { Text("Отмена") }
                        Button(onClick = {
                            vm.paste(dir) { n -> FileActions.toast(ctx, "Готово: $n") }
                        }) { Text("Вставить") }
                    }
                }
            }
        },
        floatingActionButton = {
            if (dir != null && !selecting) {
                FloatingActionButton(
                    onClick = { showNewFolder = true },
                    containerColor = cs.primary,
                    contentColor = cs.onPrimary
                ) {
                    Icon(Icons.Default.CreateNewFolder, contentDescription = "Новая папка")
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            val list = files
            when {
                list == null -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
                list.isEmpty() -> Text(
                    "Здесь пусто",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center)
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(list, key = { it.path }) { f ->
                        FileRow(
                            file = f,
                            selected = selected.contains(f),
                            selectionMode = selecting,
                            onMenu = { menuTarget = f },
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    if (selecting) toggle(f) else openFile(vm, ctx, f)
                                },
                                onLongClick = { toggle(f) }
                            )
                        )
                    }
                }
            }
        }
    }

    // Меню «Вид» (сортировка, скрытые файлы)
    if (showViewSheet) {
        ViewSheet(vm = vm, onDismiss = { showViewSheet = false })
    }

    // Меню для выделенных файлов
    if (showSelSheet) {
        val selActions = buildList<SheetAction> {
            add(SheetAction(Icons.Default.SelectAll, "Выбрать всё") {
                val all = files.orEmpty()
                selected.clear()
                selected.addAll(all)
            })
            if (dir != null) {
                add(SheetAction(Icons.Default.ContentCopy, "Копировать") {
                    vm.putToClipboard(selected.toList(), false)
                    selected.clear()
                })
                add(SheetAction(Icons.Default.ContentCut, "Переместить") {
                    vm.putToClipboard(selected.toList(), true)
                    selected.clear()
                })
            }
            if (selected.size == 1) {
                add(SheetAction(Icons.Default.Edit, "Переименовать") {
                    renameTarget = selected.first()
                })
            }
        }
        ActionSheet(
            title = "Выбрано: ${selected.size}",
            subtitle = formatSize(selectedSize),
            headerIcon = Icons.Default.SelectAll,
            headerTint = cs.primary,
            actions = selActions,
            onDismiss = { showSelSheet = false }
        )
    }

    // Меню одного файла (кнопка ⋮ в строке)
    menuTarget?.let { f ->
        val fileActions = buildList<SheetAction> {
            add(SheetAction(Icons.Default.FolderOpen, "Открыть") { openFile(vm, ctx, f) })
            if (f.isFile && !FileTypes.isText(f)) {
                add(SheetAction(Icons.Default.Description, "Открыть как текст") {
                    vm.navigate(Screen.Viewer(f, true))
                })
            }
            if (f.isFile && FileTypes.isArchive(f)) {
                add(SheetAction(Icons.Default.Unarchive, "Распаковать сюда") {
                    vm.extractZip(f, "") { n, dest ->
                        FileActions.toast(
                            ctx,
                            if (n >= 0) "Распаковано файлов: $n → ${dest.name}" else "Не удалось распаковать"
                        )
                    }
                })
            }
            if (f.isFile) {
                add(SheetAction(Icons.Default.Apps, "Открыть в другом приложении") {
                    FileActions.open(ctx, f)
                })
                add(SheetAction(Icons.Default.Share, "Поделиться") {
                    FileActions.share(ctx, listOf(f))
                })
            }
            if (dir != null) {
                add(SheetAction(Icons.Default.ContentCopy, "Копировать") {
                    vm.putToClipboard(listOf(f), false)
                })
                add(SheetAction(Icons.Default.ContentCut, "Переместить") {
                    vm.putToClipboard(listOf(f), true)
                })
            }
            add(SheetAction(Icons.Default.Edit, "Переименовать") { renameTarget = f })
            add(SheetAction(Icons.Default.Info, "Свойства") { propsTarget = f })
            add(SheetAction(Icons.Default.Delete, "Удалить", destructive = true) {
                deleteTargets = listOf(f)
            })
        }
        val sheetSubtitle = if (f.isDirectory) {
            formatDate(f.lastModified())
        } else {
            formatSize(f.length()) + " · " + formatDate(f.lastModified())
        }
        ActionSheet(
            title = f.name,
            subtitle = sheetSubtitle,
            headerIcon = iconFor(f),
            headerTint = tintFor(f),
            actions = fileActions,
            onDismiss = { menuTarget = null }
        )
    }

    deleteTargets?.let { targets ->
        AlertDialog(
            onDismissRequest = { deleteTargets = null },
            title = { Text("Удалить?") },
            text = {
                Text(
                    if (targets.size == 1) {
                        "«${targets[0].name}» будет удалён безвозвратно."
                    } else {
                        "Элементов: ${targets.size}. Это действие нельзя отменить."
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    selected.clear()
                    deleteTargets = null
                    vm.deleteFiles(targets) { n -> FileActions.toast(ctx, "Удалено: $n") }
                }) {
                    Text("Удалить", color = cs.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTargets = null }) { Text("Отмена") }
            }
        )
    }

    renameTarget?.let { target ->
        InputDialog(
            title = "Переименовать",
            initial = target.name,
            confirmText = "OK",
            onConfirm = { name ->
                renameTarget = null
                val ok = vm.rename(target, name)
                FileActions.toast(ctx, if (ok) "Переименовано" else "Не удалось переименовать")
                selected.clear()
            },
            onDismiss = { renameTarget = null }
        )
    }

    propsTarget?.let { target ->
        PropsDialog(file = target, onDismiss = { propsTarget = null })
    }

    if (showNewFolder && dir != null) {
        InputDialog(
            title = "Новая папка",
            initial = "",
            confirmText = "Создать",
            onConfirm = { name ->
                showNewFolder = false
                val ok = vm.createFolder(dir, name)
                FileActions.toast(ctx, if (ok) "Папка создана" else "Не удалось создать папку")
            },
            onDismiss = { showNewFolder = false }
        )
    }
}
