package com.filehub.app.util

import android.content.Context
import android.os.Environment
import com.filehub.app.data.ZipTools
import java.io.File

/**
 * Связка с приложением AIDE (сборка APK из исходников на телефоне).
 * AIDE ищет проекты в папке AppProjects во внутренней памяти: кладём туда проект и запускаем AIDE.
 */
object AideTools {

    fun projectsDir(): File = File(Environment.getExternalStorageDirectory(), "AppProjects")

    /** Ищет установленный AIDE: сначала com.aide.ui, потом любой com.aide.* или приложение с названием AIDE. */
    fun findPackage(ctx: Context): String? {
        val pm = ctx.packageManager
        val apps = try {
            pm.getInstalledApplications(0)
        } catch (e: Exception) {
            return null
        }
        apps.firstOrNull { it.packageName == "com.aide.ui" }?.let { return it.packageName }
        return apps.firstOrNull {
            it.packageName.startsWith("com.aide.") ||
                it.loadLabel(pm).toString().equals("AIDE", ignoreCase = true)
        }?.packageName
    }

    fun launch(ctx: Context): Boolean {
        val pkg = findPackage(ctx) ?: return false
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Кладёт проект в AppProjects. ZIP распаковывается (если внутри одна общая папка, она «поднимается»),
     * папка копируется целиком. Возвращает папку проекта или null при ошибке.
     */
    fun prepare(source: File): File? {
        return try {
            val root = projectsDir()
            root.mkdirs()
            if (source.isDirectory) {
                val dest = ZipTools.uniqueDir(root, source.name)
                if (source.copyRecursively(dest, overwrite = false)) dest else null
            } else {
                val dest = ZipTools.uniqueDir(root, source.nameWithoutExtension)
                ZipTools.extract(source, "", dest)
                flatten(dest)
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Если в папке ровно одна вложенная папка и больше ничего, делает её корнем проекта. */
    private fun flatten(dest: File): File {
        val children = dest.listFiles().orEmpty()
        if (children.size != 1 || !children[0].isDirectory) return dest

        val inner = children[0]
        val parent = dest.parentFile ?: return dest
        val tmp = File(parent, ".xcode_tmp_" + System.nanoTime())
        if (!inner.renameTo(tmp)) return dest
        dest.deleteRecursively()
        val target = ZipTools.uniqueDir(parent, inner.name)
        return if (tmp.renameTo(target)) target else tmp
    }
}
