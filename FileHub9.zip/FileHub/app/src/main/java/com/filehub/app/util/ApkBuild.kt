package com.filehub.app.util

import android.content.Context
import com.filehub.app.data.ZipTools
import java.io.File

sealed interface ApkResult {
    data class Ok(val apk: File) : ApkResult
    data class Fail(val message: String) : ApkResult
}

object ApkBuild {

    private fun isBinaryManifest(f: File): Boolean = runCatching {
        f.inputStream().use { val b = ByteArray(4); it.read(b) == 4 && b[0] == 3.toByte() && b[1] == 0.toByte() }
    }.getOrDefault(false)

    /** Папка с готовым содержимым APK (AndroidManifest.xml, classes.dex, resources.arsc…) → подписанный .apk рядом. */
    fun build(ctx: Context, folder: File): ApkResult {
        val manifest = File(folder, "AndroidManifest.xml")
        if (!manifest.isFile) {
            val src = File(folder, "build.gradle").exists() || File(folder, "build.gradle.kts").exists() ||
                File(folder, "src").isDirectory
            return ApkResult.Fail(
                if (src) "Это папка с исходниками. Компиляция Java/Kotlin здесь недоступна — " +
                    "соберите проект в AIDE/AndroidIDE или GitHub Actions, потом упакуйте результат."
                else "В папке нет AndroidManifest.xml"
            )
        }
        if (!isBinaryManifest(manifest)) {
            return ApkResult.Fail(
                "AndroidManifest.xml в текстовом виде (исходники). Нужен скомпилированный (бинарный) манифест, как в распакованном APK."
            )
        }
        return try {
            val parent = folder.parentFile ?: return ApkResult.Fail("Нет родительской папки")
            val target = uniqueFile(parent, folder.name, "apk")
            val tmp = File(ctx.cacheDir, "pack_${System.currentTimeMillis()}.apk")
            ApkPack.pack(folder, tmp)
            try {
                ApkSign.sign(ctx, tmp, target)
            } finally {
                tmp.delete()
            }
            ApkResult.Ok(target)
        } catch (e: Throwable) {
            ApkResult.Fail("Ошибка сборки: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun uniqueFile(dir: File, base: String, ext: String): File {
        var f = File(dir, "$base.$ext")
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i).$ext"); i++ }
        return f
    }
}
