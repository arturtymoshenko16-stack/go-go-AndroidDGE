@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.FileTypes
import com.filehub.app.data.ZipItem
import com.filehub.app.data.ZipTools
import com.filehub.app.data.formatDate
import com.filehub.app.data.formatSize
import com.filehub.app.util.AideTools
import com.filehub.app.util.FileActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Просмотр ZIP внутри приложения: заходим в папки, открываем файлы, распаковываем. */
@Composable
fun ArchiveScreen(vm: MainViewModel, zip: File, prefix: String) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()

    var items by remember { mutableStateOf<List<ZipItem>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var menuTarget by remember { mutableStateOf<ZipItem?>(null) }
    var aideMissing by remember { mutableStateOf(false) }

    LaunchedEffect(zip, prefix) {
        val result = withContext(Dispatchers.IO) { runCatching { ZipTools.list(zip, prefix) } }
        result.onSuccess { items = it }.onFailure { failed = true }
    }

    fun openEntry(item: ZipItem) {
        if (item.isDir) {
            vm.navigate(Screen.Archive(zip, item.path))
            return
        }
        scope.launch {
            busy = true
            val f = withContext(Dispatchers.IO) {
                runCatching { ZipTools.extractToCache(ctx, zip, item.path) }.getOrNull()
            }
            busy = false
            when {
                f == null -> FileActions.toast(ctx, "Не удалось открыть файл из архива")
                FileTypes.isImage(f) || FileTypes.isText(f) || FileTypes.looksLikeText(f) ->
                    vm.navigate(Screen.Viewer(f, readOnly = true))
                else -> FileActions.open(ctx, f)
            }
        }
    }

    fun extract(entry: String) {
        vm.extractZip(zip, entry) { n, dest ->
            FileActions.toast(
                ctx,
                if (n >= 0) "Распаковано файлов: $n → ${dest.name}" else "Не удалось распаковать"
            )
        }
    }

    val title = if (prefix.isEmpty()) zip.name else prefix.trimEnd('/').substringAfterLast('/')
    val subtitle = if (prefix.isEmpty()) formatSize(zip.length()) else zip.name + " / " + prefix

    Scaffold(
        containerColor = cs.background,
        topBar = {
            SimpleTopBar(
                title = title,
                subtitle = subtitle,
                onBack = { vm.back() },
                actions = {
                    IconButton(onClick = {
                        if (AideTools.findPackage(ctx) == null) {
                            aideMissing = true
                        } else {
                            vm.prepareAide(zip) { dest ->
                                if (dest == null) {
                                    FileActions.toast(ctx, "Не удалось подготовить проект")
                                } else {
                                    FileActions.toast(ctx, "Проект: AppProjects/${dest.name}")
                                    AideTools.launch(ctx)
                                }
                            }
                        }
                    }) {
                        Icon(Icons.Default.Code, contentDescription = "Открыть проект в AIDE")
                    }
                    IconButton(onClick = { extract("") }) {
                        Icon(Icons.Default.Unarchive, contentDescription = "Распаковать всё")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            val list = items
            when {
                failed -> Text(
                    "Не удалось прочитать архив",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center)
                )
                list == null -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                list.isEmpty() -> Text(
                    "Папка пуста",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center)
                )
                else -> LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(list, key = { it.path }) { item ->
                        ZipRow(
                            item = item,
                            onClick = { openEntry(item) },
                            onMenu = { menuTarget = item }
                        )
                    }
                }
            }
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }

    if (aideMissing) {
        AideMissingDialog(onDismiss = { aideMissing = false })
    }

    menuTarget?.let { item ->
        val actions = buildList<SheetAction> {
            add(SheetAction(Icons.Default.FolderOpen, "Открыть") { openEntry(item) })
            add(SheetAction(Icons.Default.Unarchive, "Распаковать рядом с архивом") {
                extract(item.path)
            })
            if (!item.isDir) {
                add(SheetAction(Icons.Default.Apps, "Открыть в другом приложении") {
                    scope.launch {
                        val f = withContext(Dispatchers.IO) {
                            runCatching { ZipTools.extractToCache(ctx, zip, item.path) }.getOrNull()
                        }
                        if (f != null) FileActions.open(ctx, f)
                        else FileActions.toast(ctx, "Не удалось открыть файл из архива")
                    }
                })
            }
        }
        ActionSheet(
            title = item.name,
            subtitle = if (item.isDir) "Папка в архиве" else formatSize(item.size),
            headerIcon = if (item.isDir) Icons.Default.Folder else iconFor(File(item.name)),
            headerTint = if (item.isDir) FolderColor else tintFor(File(item.name)),
            actions = actions,
            onDismiss = { menuTarget = null }
        )
    }
}

@Composable
private fun ZipRow(item: ZipItem, onClick: () -> Unit, onMenu: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val fake = File(item.name)
    val tint = if (item.isDir) FolderColor else tintFor(fake)
    val icon = if (item.isDir) Icons.Default.Folder else iconFor(fake)
    val sub = if (item.isDir) {
        "Папка"
    } else {
        formatSize(item.size) + if (item.time > 0) " · " + formatDate(item.time) else ""
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(tint.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = tint)
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                item.name,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                sub,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1
            )
        }
        IconButton(onClick = onMenu, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.MoreVert, contentDescription = "Меню", tint = cs.onSurfaceVariant)
        }
    }
}
