package com.filehub.app.ui

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable

@Composable
fun AideMissingDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AIDE не установлен") },
        text = {
            Text(
                "Установите приложение AIDE и повторите. Проект будет положен в папку " +
                    "AppProjects во внутренней памяти, а AIDE соберёт из него APK прямо на телефоне."
            )
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("OK") }
        }
    )
}
