@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.DisableSelection
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.filehub.app.MainViewModel
import com.filehub.app.data.FileTypes
import com.filehub.app.data.formatSize
import com.filehub.app.util.FileActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

private const val MAX_BYTES = 1_000_000

private class Loaded(
    val text: String,
    val truncated: Boolean,
    val charset: Charset,
    val crlf: Boolean,
    val bom: Boolean
)

/** Читает до 1 МБ. Кодировка: UTF-8, а если не подходит — windows-1251 (частый случай для русских файлов). */
private fun readTextFile(file: File): Loaded {
    val buf = ByteArray(MAX_BYTES + 1)
    var total = 0
    file.inputStream().use { input ->
        while (total < buf.size) {
            val n = input.read(buf, total, buf.size - total)
            if (n <= 0) break
            total += n
        }
    }
    val truncated = total > MAX_BYTES
    val len = if (truncated) MAX_BYTES else total
    val (decoded, charset) = decodeBytes(buf, len)
    val bom = decoded.startsWith("﻿")
    var text = decoded.removePrefix("﻿")
    val crlf = text.contains("\r\n")
    if (crlf) text = text.replace("\r\n", "\n")
    return Loaded(text, truncated, charset, crlf, bom)
}

private fun decodeBytes(bytes: ByteArray, len: Int): Pair<String, Charset> {
    // Обрезка могла разрезать многобайтный символ, поэтому пробуем отступить на пару байт.
    for (cut in 0..3) {
        if (len - cut < 0) break
        try {
            val decoder = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            val s = decoder.decode(ByteBuffer.wrap(bytes, 0, len - cut)).toString()
            return s to Charsets.UTF_8
        } catch (e: CharacterCodingException) {
            // пробуем дальше
        }
    }
    val cp = Charset.forName("windows-1251")
    return String(bytes, 0, len, cp) to cp
}

private fun writeTextFile(file: File, text: String, loaded: Loaded) {
    val body = if (loaded.crlf) text.replace("\n", "\r\n") else text
    val data = body.toByteArray(loaded.charset)
    val withBom = if (loaded.bom && loaded.charset == Charsets.UTF_8) {
        byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + data
    } else {
        data
    }
    file.writeBytes(withBom)
}

private fun decodeSampled(file: File, maxSide: Int): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) {
        sample *= 2
    }
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeFile(file.path, options)?.asImageBitmap()
}

@Composable
fun ViewerScreen(vm: MainViewModel, file: File, asText: Boolean, readOnly: Boolean) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val isImage = !asText && FileTypes.isImage(file)

    var loaded by remember { mutableStateOf<Loaded?>(null) }
    var text by remember { mutableStateOf("") } // сохранённое содержимое
    var edited by remember { mutableStateOf("") } // буфер редактора
    var editing by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var fontSize by remember { mutableIntStateOf(14) }
    var showMenu by remember { mutableStateOf(false) }
    var showDiscard by remember { mutableStateOf(false) }

    LaunchedEffect(file) {
        if (!isImage) {
            val result = withContext(Dispatchers.IO) { runCatching { readTextFile(file) } }
            result
                .onSuccess {
                    loaded = it
                    text = it.text
                }
                .onFailure { failed = true }
        }
    }

    val current = loaded
    val canEdit = !isImage && !readOnly && current != null && !current.truncated
    val dirty = editing && edited != text

    fun save(onDone: () -> Unit = {}) {
        val info = current ?: return
        val value = edited
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { writeTextFile(file, value, info) }.isSuccess
            }
            if (ok) {
                text = value
                vm.tick++
                FileActions.toast(ctx, "Сохранено")
                onDone()
            } else {
                FileActions.toast(ctx, "Не удалось сохранить файл")
            }
        }
    }

    BackHandler(enabled = dirty) { showDiscard = true }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            SimpleTopBar(
                title = file.name,
                subtitle = if (dirty) "Есть несохранённые изменения"
                else if (readOnly) formatSize(file.length()) + " · только чтение"
                else formatSize(file.length()),
                onBack = { if (dirty) showDiscard = true else vm.back() },
                actions = {
                    if (!isImage) {
                        IconButton(onClick = { if (fontSize > 8) fontSize -= 2 }) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "Меньше")
                        }
                        IconButton(onClick = { if (fontSize < 32) fontSize += 2 }) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "Больше")
                        }
                    }
                    if (editing) {
                        IconButton(onClick = { save() }, enabled = dirty) {
                            Icon(Icons.Default.Save, contentDescription = "Сохранить")
                        }
                    } else if (canEdit) {
                        IconButton(onClick = {
                            edited = text
                            editing = true
                        }) {
                            Icon(Icons.Default.Edit, contentDescription = "Редактировать")
                        }
                    }
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Меню")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when {
                isImage -> ImageContent(file)
                failed -> Text(
                    "Не удалось прочитать файл",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center)
                )
                current == null -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
                editing -> EditorContent(
                    value = edited,
                    onChange = { edited = it },
                    fontSize = fontSize
                )
                else -> TextContent(text, current.truncated, fontSize)
            }
        }
    }

    if (showMenu) {
        val actions = buildList<SheetAction> {
            if (!isImage && current != null) {
                add(SheetAction(Icons.Default.ContentCopy, "Копировать весь текст") {
                    clipboard.setText(AnnotatedString(if (editing) edited else text))
                    FileActions.toast(ctx, "Скопировано")
                })
            }
            add(SheetAction(Icons.Default.Share, "Поделиться") {
                FileActions.share(ctx, listOf(file))
            })
            add(SheetAction(Icons.Default.Apps, "Открыть в другом приложении") {
                FileActions.open(ctx, file)
            })
        }
        ActionSheet(
            title = file.name,
            subtitle = formatSize(file.length()),
            headerIcon = iconFor(file),
            headerTint = tintFor(file),
            actions = actions,
            onDismiss = { showMenu = false }
        )
    }

    if (showDiscard) {
        AlertDialog(
            onDismissRequest = { showDiscard = false },
            title = { Text("Сохранить изменения?") },
            text = { Text("В файле есть несохранённые правки.") },
            confirmButton = {
                TextButton(onClick = {
                    showDiscard = false
                    save { vm.back() }
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { showDiscard = false }) { Text("Отмена") }
                    TextButton(onClick = {
                        showDiscard = false
                        vm.back()
                    }) { Text("Не сохранять", color = cs.error) }
                }
            }
        )
    }
}

@Composable
private fun EditorContent(value: String, onChange: (String) -> Unit, fontSize: Int) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        BasicTextField(
            value = value,
            onValueChange = onChange,
            textStyle = TextStyle(
                color = cs.onBackground,
                fontFamily = FontFamily.Monospace,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.45f).sp
            ),
            cursorBrush = SolidColor(cs.primary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 120.dp)
        )
    }
}

@Composable
private fun TextContent(text: String, truncated: Boolean, fontSize: Int) {
    val cs = MaterialTheme.colorScheme
    val lines = remember(text) { text.split('\n') }

    Column(modifier = Modifier.fillMaxSize()) {
        if (truncated) {
            Text(
                "Показан только первый мегабайт файла (редактирование недоступно)",
                style = MaterialTheme.typography.bodySmall,
                color = cs.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(cs.surface)
                    .padding(10.dp)
            )
        }
        SelectionContainer(modifier = Modifier.weight(1f)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                itemsIndexed(lines) { index, line ->
                    Row {
                        DisableSelection {
                            Text(
                                "${index + 1}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = (fontSize - 3).sp,
                                color = cs.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.width(44.dp)
                            )
                        }
                        Text(
                            line.ifEmpty { " " },
                            fontFamily = FontFamily.Monospace,
                            fontSize = fontSize.sp,
                            lineHeight = (fontSize * 1.45f).sp,
                            color = cs.onBackground,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageContent(file: File) {
    val cs = MaterialTheme.colorScheme
    var bitmap by remember(file) { mutableStateOf<ImageBitmap?>(null) }
    var failed by remember(file) { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    LaunchedEffect(file) {
        val decoded = withContext(Dispatchers.IO) { decodeSampled(file, 2048) }
        if (decoded == null) failed = true else bitmap = decoded
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    scale = 1f
                    offset = Offset.Zero
                })
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (scale * zoom).coerceIn(1f, 6f)
                    scale = newScale
                    offset = if (newScale <= 1f) Offset.Zero else offset + pan
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val image = bitmap
        when {
            failed -> Text("Не удалось открыть изображение", color = cs.onSurfaceVariant)
            image == null -> CircularProgressIndicator()
            else -> Image(
                bitmap = image,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            )
        }
    }
}
