#!/system/bin/sh
# Шаблон: сборка .so из C/C++ для arm64-v8a.
# Вызов: sh build-so.sh <папка_проекта> <папка_libs>
# Исходники: <проект>/jni/*.c *.cpp или <проект>/*.c *.cpp
PROJECT="$1"
OUT="$2"
NAME=$(basename "$PROJECT")

CLANG=$(find "$TOOLCHAIN" -name 'aarch64-linux-android*-clang' 2>/dev/null | sort | tail -n 1)
if [ -z "$CLANG" ]; then
  echo "Не найден aarch64-linux-android*-clang в $TOOLCHAIN"
  exit 1
fi
CLANGXX="${CLANG}++"

CSRC=$(find "$PROJECT/jni" "$PROJECT" -maxdepth 1 -name '*.c' 2>/dev/null | sort -u)
CPPSRC=$(find "$PROJECT/jni" "$PROJECT" -maxdepth 1 -name '*.cpp' 2>/dev/null | sort -u)
if [ -z "$CSRC" ] && [ -z "$CPPSRC" ]; then
  echo "Нет исходников .c/.cpp в $PROJECT или $PROJECT/jni"
  exit 1
fi

mkdir -p "$OUT/arm64-v8a"
if [ -n "$CPPSRC" ]; then
  "$CLANGXX" -shared -fPIC -O2 -static-libstdc++ -o "$OUT/arm64-v8a/lib$NAME.so" $CSRC $CPPSRC -llog -landroid
else
  "$CLANG" -shared -fPIC -O2 -o "$OUT/arm64-v8a/lib$NAME.so" $CSRC -llog -landroid -landroid
fi
echo "Готово: $OUT/arm64-v8a/lib$NAME.so"
