#!/system/bin/sh
# Шаблон: сборка APK из простого Java-проекта (без Gradle).
# Вызов: sh build.sh <папка_проекта> <выход_unsigned.apk>
# Структура проекта: AndroidManifest.xml, res/, src/ (*.java), libs/arm64-v8a/*.so (по желанию)
PROJECT="$1"
OUT="$2"
W="$TMPDIR/xcode_build"
rm -rf "$W"; mkdir -p "$W/gen" "$W/classes" "$W/dex"

find_one() { find "$TOOLCHAIN" -name "$1" 2>/dev/null | head -n 1; }
AAPT2=$(find_one aapt2)
JAR=$(find_one android.jar)
D8=$(find_one d8)
JAVAC=$(find_one javac)
[ -z "$JAVAC" ] && JAVAC=$(command -v javac)
for x in "$AAPT2:aapt2" "$JAR:android.jar" "$D8:d8" "$JAVAC:javac"; do
  [ -z "${x%%:*}" ] && { echo "В наборе нет: ${x##*:}"; exit 1; }
done

cd "$PROJECT" || exit 1
if [ -d res ]; then
  "$AAPT2" compile --dir res -o "$W/res.zip" || exit 1
  RES="$W/res.zip"
fi
"$AAPT2" link -o "$W/base.apk" -I "$JAR" --manifest AndroidManifest.xml \
  --java "$W/gen" --min-sdk-version 26 --target-sdk-version 28 $RES || exit 1

SRCS=$(find src "$W/gen" -name '*.java' 2>/dev/null)
if [ -n "$SRCS" ]; then
  "$JAVAC" -source 8 -target 8 -cp "$JAR" -d "$W/classes" $SRCS || exit 1
  "$D8" --lib "$JAR" --output "$W/dex" $(find "$W/classes" -name '*.class') || exit 1
  cd "$W/dex" && zip -q -u "$W/base.apk" classes.dex || exit 1
fi
if [ -d "$PROJECT/libs" ]; then
  mkdir -p "$W/pk/lib" && cp -r "$PROJECT/libs/." "$W/pk/lib/"
  cd "$W/pk" && zip -q -r "$W/base.apk" lib
fi
cp "$W/base.apk" "$OUT"
echo "Готово: $OUT"
