#!/system/bin/sh
# Шаблон: упаковка ресурсов и манифеста для приложения на C++ (NativeActivity), без Java.
# Вызов: sh build-native.sh <папка_проекта> <папка_вывода>
# Результат: в папке вывода — бинарный AndroidManifest.xml и resources.arsc. .so добавляет приложение.
PROJECT="$1"
OUTDIR="$2"
AAPT2=$(find "$TOOLCHAIN" -name aapt2 2>/dev/null | head -n 1)
JAR=$(find "$TOOLCHAIN" -name android.jar 2>/dev/null | head -n 1)
[ -z "$AAPT2" ] && { echo "В наборе нет aapt2"; exit 1; }
[ -z "$JAR" ] && { echo "В наборе нет android.jar"; exit 1; }
chmod +x "$AAPT2" 2>/dev/null
rm -rf "$OUTDIR"; mkdir -p "$OUTDIR"
cd "$PROJECT" || exit 1
RES=""
if [ -d res ]; then
  "$AAPT2" compile --dir res -o "$TMPDIR/xcode_res.zip" || exit 1
  RES="$TMPDIR/xcode_res.zip"
fi
"$AAPT2" link --output-to-dir -o "$OUTDIR" -I "$JAR" --manifest AndroidManifest.xml \
  --min-sdk-version 26 --target-sdk-version 28 $RES || exit 1
echo "Готово: $OUTDIR"
