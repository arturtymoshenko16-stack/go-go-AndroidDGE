@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.data.FileTypes
import com.filehub.app.data.SortMode
import com.filehub.app.data.formatDate
import com.filehub.app.data.formatSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class SheetAction(
    val icon: ImageVector,
    val label: String,
    val destructive: Boolean = false,
    val onClick: () -> Unit
)

/** Нижнее меню действий: заголовок с иконкой и список действий. */
@Composable
fun ActionSheet(
    title: String,
    subtitle: String?,
    headerIcon: ImageVector,
    headerTint: Color,
    actions: List<SheetAction>,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = cs.surface
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(headerTint.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(headerIcon, contentDescription = null, tint = headerTint)
                }
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = cs.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (subtitle != null) {
                        Text(
                            subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 8.dp),
                color = cs.surfaceVariant
            )
            for (action in actions) {
                val iconColor = if (action.destructive) cs.error else cs.onSurfaceVariant
                val textColor = if (action.destructive) cs.error else cs.onSurface
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onDismiss()
                            action.onClick()
                        }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(action.icon, contentDescription = null, tint = iconColor)
                    Spacer(Modifier.width(18.dp))
                    Text(action.label, color = textColor)
                }
            }
        }
    }
}

/** Меню «Вид»: сортировка и скрытые файлы. */
@Composable
fun ViewSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = cs.surface
    ) {
        Column(modifier = Modifier.padding(bottom = 24.dp)) {
            Text(
                "Вид",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = cs.onSurface,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
            Text(
                "Сортировка",
                style = MaterialTheme.typography.labelLarge,
                color = cs.primary,
                modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp)
            )
            for (mode in SortMode.values()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.changeSort(mode) }
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = vm.sort == mode, onClick = null)
                    Spacer(Modifier.width(14.dp))
                    Text(mode.label, color = cs.onSurface)
                }
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 8.dp),
                color = cs.surfaceVariant
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.setHidden(!vm.showHidden) }
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Показывать скрытые файлы",
                    color = cs.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Switch(checked = vm.showHidden, onCheckedChange = null)
            }
        }
    }
}

@Composable
fun PropsDialog(file: File, onDismiss: () -> Unit) {
    var size by remember(file) { mutableStateOf<Long?>(null) }

    LaunchedEffect(file) {
        size = withContext(Dispatchers.IO) {
            if (file.isFile) {
                file.length()
            } else {
                file.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            }
        }
    }

    val type = if (file.isDirectory) {
        "Папка"
    } else {
        val ext = file.extension
        val cat = FileTypes.categoryOf(file).label
        if (ext.isEmpty()) cat else "$cat (.$ext)"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Свойства") },
        text = {
            Column {
                PropLine("Имя", file.name)
                PropLine("Путь", file.parent ?: "")
                PropLine("Тип", type)
                PropLine("Размер", size?.let { formatSize(it) } ?: "считаю…")
                PropLine("Изменён", formatDate(file.lastModified()))
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("OK") }
        }
    )
}

@Composable
private fun PropLine(label: String, value: String) {
    Column(modifier = Modifier.padding(bottom = 10.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
