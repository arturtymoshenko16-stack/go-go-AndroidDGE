@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.Category
import com.filehub.app.data.formatSize
import java.io.File

@Composable
fun CleanScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val scan = vm.scan
    val storage = vm.storage

    Scaffold(
        containerColor = cs.background,
        topBar = {
            SimpleTopBar(
                title = "Очистка памяти",
                subtitle = "Свободно: ${formatSize(storage.free)} / Всего: ${formatSize(storage.total)}",
                onBack = { vm.back() }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (scan == null) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Анализ памяти…", color = cs.onSurfaceVariant)
                    }
                }
            } else {
                item {
                    CleanCard(
                        title = "Загрузки",
                        subtitle = "Файлов в папке загрузок: ${scan.downloads.size}",
                        freeUp = scan.downloadsSize,
                        files = scan.downloads,
                        onClick = { vm.navigate(Screen.Browser(vm.repo.downloads)) }
                    )
                }
                item {
                    CleanCard(
                        title = "Крупные файлы",
                        subtitle = "Файлов от 10 МБ: ${scan.largeCount}",
                        freeUp = scan.largeSize,
                        files = scan.large,
                        onClick = { vm.navigate(Screen.Large) }
                    )
                }
                item {
                    CleanCard(
                        title = "Установочные файлы",
                        subtitle = "APK-файлы, которые можно удалить после установки",
                        freeUp = scan.sizes[Category.APPS] ?: 0L,
                        files = emptyList(),
                        onClick = { vm.navigate(Screen.CategoryList(Category.APPS)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CleanCard(
    title: String,
    subtitle: String,
    freeUp: Long,
    files: List<File>,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = cs.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    "Освободить ${formatSize(freeUp)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurface
                )
                Icon(
                    Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = cs.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant
            )
            if (files.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (f in files.take(5)) {
                        PreviewTile(f)
                    }
                    if (files.size > 5) {
                        MoreTile(files.size - 5)
                    }
                }
            }
        }
    }
}

@Composable
private fun PreviewTile(file: File) {
    val cs = MaterialTheme.colorScheme
    val tint = tintFor(file)
    Column(
        modifier = Modifier.width(48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(tint.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(iconFor(file), contentDescription = null, tint = tint)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            file.name,
            fontSize = 10.sp,
            color = cs.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun MoreTile(count: Int) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .size(44.dp)
            .border(1.5.dp, cs.onSurfaceVariant, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "+$count",
            fontSize = 11.sp,
            color = cs.onSurfaceVariant,
            maxLines = 1
        )
    }
}
