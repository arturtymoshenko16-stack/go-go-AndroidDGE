package com.filehub.app.ui

import android.content.Context
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.FileTypes
import com.filehub.app.util.FileActions
import java.io.File

/**
 * Папки открываются в обзоре, ZIP — во встроенном просмотрщике архивов (APK открывается на установку),
 * текст и картинки — во встроенном просмотрщике/редакторе, остальное — во внешнем приложении.
 */
fun openFile(vm: MainViewModel, ctx: Context, file: File) {
    when {
        file.isDirectory -> vm.navigate(Screen.Browser(file))
        FileTypes.isArchive(file) -> vm.navigate(Screen.Archive(file))
        FileTypes.isImage(file) -> vm.navigate(Screen.Viewer(file))
        FileTypes.isText(file) || FileTypes.looksLikeText(file) -> vm.navigate(Screen.Viewer(file))
        else -> FileActions.open(ctx, file)
    }
}
