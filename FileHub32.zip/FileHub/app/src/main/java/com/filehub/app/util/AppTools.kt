package com.filehub.app.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Environment
import java.io.File

class AppInfoItem(
    val label: String,
    val packageName: String,
    val versionName: String,
    val apkPaths: List<String>,
    val isSystem: Boolean,
    val size: Long
)

object AppTools {

    fun backupDir(): File = File(Environment.getExternalStorageDirectory(), "FileHub/APK")

    fun loadApps(ctx: Context): List<AppInfoItem> {
        val pm = ctx.packageManager
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val result = ArrayList<AppInfoItem>()
        for (ai in installed) {
            val paths = ArrayList<String>()
            if (ai.sourceDir != null) paths.add(ai.sourceDir)
            val splits = ai.splitSourceDirs
            if (splits != null) paths.addAll(splits)

            var size = 0L
            for (p in paths) size += File(p).length()

            val version = try {
                pm.getPackageInfo(ai.packageName, 0).versionName ?: ""
            } catch (e: Exception) {
                ""
            }
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

            result.add(
                AppInfoItem(
                    label = ai.loadLabel(pm).toString(),
                    packageName = ai.packageName,
                    versionName = version,
                    apkPaths = paths,
                    isSystem = isSystem,
                    size = size
                )
            )
        }
        return result.sortedBy { it.label.lowercase() }
    }

    private fun safeName(s: String): String {
        return s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
    }

    /**
     * Копирует APK приложения в destRoot. Обычное приложение — один файл,
     * приложение со split-APK — папка со всеми частями. Возвращает файл/папку или null при ошибке.
     */
    fun extract(app: AppInfoItem, destRoot: File): File? {
        return try {
            destRoot.mkdirs()
            val base = safeName(app.label + "_" + app.versionName)
            if (app.apkPaths.size <= 1) {
                val dst = File(destRoot, "$base.apk")
                File(app.apkPaths[0]).copyTo(dst, overwrite = true)
                dst
            } else {
                val dir = File(destRoot, base)
                dir.mkdirs()
                for (p in app.apkPaths) {
                    val src = File(p)
                    src.copyTo(File(dir, src.name), overwrite = true)
                }
                dir
            }
        } catch (e: Exception) {
            null
        }
    }
}
