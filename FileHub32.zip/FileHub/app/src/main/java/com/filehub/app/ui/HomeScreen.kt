package com.filehub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.Screen

/** Главный экран: панель ☰ 💾 ▶ ✏️ ⚙ и пустое поле. Файл открывается через ☰ → папка → файл. */
@Composable
fun HomeScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    Scaffold(
        containerColor = cs.background,
        topBar = {
            SimpleTopBar(
                title = "Android XCODE",
                navIcon = Icons.Default.Menu,
                onBack = { vm.openDrawer() },
                actions = {
                    IconButton(onClick = {}, enabled = false) {
                        Icon(Icons.Default.Save, contentDescription = "Сохранить")
                    }
                    IconButton(onClick = {}, enabled = false) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Создать APK")
                    }
                    IconButton(onClick = {}, enabled = false) {
                        Icon(Icons.Default.Edit, contentDescription = "Редактировать")
                    }
                    IconButton(onClick = { vm.navigate(Screen.Settings) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Настройки")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFFFDFDFD))
        ) {
            Text(
                "Нажмите ☰ и выберите папку и файл",
                color = Color(0xFF8A8A8A),
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }
    }
}
