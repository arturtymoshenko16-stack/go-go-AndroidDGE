package com.filehub.app.util

import java.io.File
import java.io.FilterOutputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Упаковка папки в zip/APK с выравниванием (resources.arsc — 4 байта, *.so — 4096). */
object ApkPack {

    private class Counting(out: OutputStream) : FilterOutputStream(out) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    private fun alignOf(name: String): Int = when {
        name == "resources.arsc" -> 4
        name.endsWith(".so") -> 4096
        else -> 0
    }

    fun collect(root: File): List<Pair<String, File>> {
        val list = ArrayList<Pair<String, File>>()
        fun walk(dir: File, prefix: String) {
            val items = dir.listFiles()?.sortedBy { it.name } ?: return
            for (f in items) {
                val name = prefix + f.name
                if (f.isDirectory) walk(f, "$name/") else list.add(name to f)
            }
        }
        walk(root, "")
        return list
            .filterNot { (n, _) ->
                n.startsWith("META-INF/") &&
                    (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") ||
                        n.endsWith(".EC") || n.endsWith("MANIFEST.MF"))
            }
            // манифест первым, как в обычных APK
            .sortedBy { if (it.first == "AndroidManifest.xml") 0 else 1 }
    }

    fun pack(root: File, out: File) {
        val entries = collect(root)
        out.parentFile?.mkdirs()
        out.outputStream().use { fos ->
            val counter = Counting(fos)
            ZipOutputStream(counter).use { zip ->
                for ((name, file) in entries) {
                    val align = alignOf(name)
                    val e = ZipEntry(name)
                    e.time = file.lastModified()
                    if (align > 0) {
                        val crc = CRC32()
                        file.inputStream().use { ins ->
                            val buf = ByteArray(65536)
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                crc.update(buf, 0, n)
                            }
                        }
                        e.method = ZipEntry.STORED
                        e.size = file.length()
                        e.compressedSize = file.length()
                        e.crc = crc.value
                        val nameLen = name.toByteArray(Charsets.UTF_8).size
                        val dataStart = counter.count + 30 + nameLen
                        val pad = ((align - dataStart % align) % align).toInt()
                        if (pad > 0) {
                            val extraLen = if (pad < 4) pad + align else pad
                            val extra = ByteArray(extraLen)
                            extra[0] = 0x35; extra[1] = 0xD9.toByte()
                            val dl = extraLen - 4
                            extra[2] = (dl and 0xFF).toByte(); extra[3] = ((dl shr 8) and 0xFF).toByte()
                            e.extra = extra
                        }
                    } else {
                        e.method = ZipEntry.DEFLATED
                    }
                    zip.putNextEntry(e)
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }
}
