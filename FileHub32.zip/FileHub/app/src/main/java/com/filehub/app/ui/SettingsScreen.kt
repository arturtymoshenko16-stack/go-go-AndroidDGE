@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.filehub.app.util.FileActions
import com.filehub.app.util.Toolchain
import java.io.File
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.data.SortMode

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    var installing by remember { mutableStateOf(false) }
    var status by remember { mutableIntStateOf(0) }
    status.let { }

    Scaffold(
        containerColor = cs.background,
        topBar = { SimpleTopBar(title = "Настройки", onBack = { vm.back() }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            SettingsHeader("Внешний вид")
            SwitchRow("Тёмная тема", null, vm.darkTheme) { vm.setDark(it) }

            SettingsHeader("Файлы")
            SwitchRow(
                "Показывать скрытые файлы",
                "Файлы и папки, имя которых начинается с точки",
                vm.showHidden
            ) { vm.setHidden(it) }
            SwitchRow(
                "Недавние на главной",
                "Последние изменённые файлы",
                vm.showRecent
            ) { vm.setRecent(it) }

            SettingsHeader("Сортировка в папках")
            for (mode in SortMode.values()) {
                RadioRow(mode.label, vm.sort == mode) { vm.changeSort(mode) }
            }

            SettingsHeader("Инструменты сборки")
            Text(
                "Укажите путь к архиву .tar.gz или .zip с инструментами. Можно ставить несколько архивов подряд " +
                    "(NDK, SDK-инструменты): они добавляются в один набор. Пример: /storage/emulated/0/Download/ndk_arm64.tar.gz",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            OutlinedTextField(
                value = vm.toolchainPath,
                onValueChange = { vm.changeToolchainPath(it) },
                label = { Text("Путь к файлу") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
            Text(
                if (Toolchain.root(ctx) != null) "Статус: установлены" else "Статус: не установлены",
                color = cs.onBackground,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Text(
                Toolchain.summary(ctx),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Button(
                onClick = {
                    val added = Toolchain.addTemplates(ctx)
                    status++
                    FileActions.toast(
                        ctx,
                        if (added.isEmpty()) "Набор не установлен"
                        else "Шаблоны обновлены: ${added.joinToString()}"
                    )
                },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            ) { Text("Обновить шаблоны скриптов") }
            Button(
                onClick = {
                    Toolchain.clear(ctx)
                    status++
                    FileActions.toast(ctx, "Набор удалён")
                },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            ) { Text("Удалить набор") }
            Button(
                enabled = !installing,
                onClick = {
                    val f = File(vm.toolchainPath.trim())
                    if (!f.isFile) {
                        FileActions.toast(ctx, "Файл не найден: ${f.path}")
                    } else {
                        installing = true
                        FileActions.toast(ctx, "Установка… может занять минуту")
                        vm.installToolchain(f) { n, err ->
                            installing = false
                            status++
                            FileActions.toast(
                                ctx,
                                if (err == null) "Установлено файлов: $n" else "Ошибка: $err"
                            )
                        }
                    }
                },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text(if (installing) "Установка…" else "Установить") }

            SettingsHeader("О приложении")
            Text(
                "Android XCODE 1.0\nПростой файловый менеджер с открытым исходным кодом.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun SettingsHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp)
    )
}

@Composable
private fun SwitchRow(
    title: String,
    description: String?,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = cs.onBackground)
            if (description != null) {
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(label, color = MaterialTheme.colorScheme.onBackground)
    }
}
