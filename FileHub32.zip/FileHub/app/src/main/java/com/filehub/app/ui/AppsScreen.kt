@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.Category
import com.filehub.app.data.formatSize
import com.filehub.app.util.AppInfoItem
import com.filehub.app.util.AppTools
import com.filehub.app.util.FileActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Список установленных приложений: можно извлечь APK, поделиться, запустить, удалить. */
@Composable
fun AppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()

    var apps by remember { mutableStateOf<List<AppInfoItem>?>(null) }
    var query by remember { mutableStateOf("") }
    var showSystem by remember { mutableStateOf(false) }
    var menuTarget by remember { mutableStateOf<AppInfoItem?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { AppTools.loadApps(ctx) }
    }

    val shown = remember(apps, query, showSystem) {
        apps.orEmpty().filter { app ->
            (showSystem || !app.isSystem) &&
                (query.isBlank() ||
                    app.label.contains(query, ignoreCase = true) ||
                    app.packageName.contains(query, ignoreCase = true))
        }
    }

    fun extractApk(app: AppInfoItem, thenShare: Boolean) {
        scope.launch {
            busy = true
            val out = withContext(Dispatchers.IO) { AppTools.extract(app, AppTools.backupDir()) }
            busy = false
            if (out == null) {
                FileActions.toast(ctx, "Не удалось извлечь APK")
            } else {
                vm.tick++
                if (thenShare && out.isFile) {
                    FileActions.share(ctx, listOf(out))
                } else {
                    FileActions.toast(ctx, "Сохранено в FileHub/APK: ${out.name}")
                }
            }
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            SimpleTopBar(
                title = "Приложения",
                subtitle = apps?.let { "Всего: ${it.count { a -> !a.isSystem }} (системных: ${it.count { a -> a.isSystem }})" },
                onBack = { vm.back() },
                actions = {
                    IconButton(onClick = { vm.navigate(Screen.CategoryList(Category.APPS)) }) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "APK-файлы")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Поиск приложения") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = showSystem,
                    onClick = { showSystem = !showSystem },
                    label = { Text("Системные") }
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                when {
                    apps == null -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    shown.isEmpty() -> Text(
                        "Ничего не найдено",
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.align(Alignment.Center)
                    )
                    else -> LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(shown, key = { it.packageName }) { app ->
                            AppRow(app = app, onClick = { menuTarget = app })
                        }
                    }
                }
                if (busy) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }

    menuTarget?.let { app ->
        val actions = buildList<SheetAction> {
            add(SheetAction(Icons.Default.Download, "Извлечь APK") { extractApk(app, false) })
            add(SheetAction(Icons.Default.Share, "Поделиться APK") { extractApk(app, true) })
            if (ctx.packageManager.getLaunchIntentForPackage(app.packageName) != null) {
                add(SheetAction(Icons.Default.PlayArrow, "Запустить") {
                    ctx.packageManager.getLaunchIntentForPackage(app.packageName)?.let {
                        try {
                            ctx.startActivity(it)
                        } catch (e: Exception) {
                            FileActions.toast(ctx, "Не удалось запустить")
                        }
                    }
                })
            }
            add(SheetAction(Icons.Default.Info, "О приложении") {
                try {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")
                        )
                    )
                } catch (e: Exception) {
                    FileActions.toast(ctx, "Не удалось открыть настройки")
                }
            })
            if (!app.isSystem) {
                add(SheetAction(Icons.Default.Delete, "Удалить", destructive = true) {
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                        )
                    } catch (e: Exception) {
                        FileActions.toast(ctx, "Не удалось удалить")
                    }
                })
            }
        }
        val parts = if (app.apkPaths.size > 1) " · ${app.apkPaths.size} частей" else ""
        ActionSheet(
            title = app.label,
            subtitle = "${app.packageName}\n${app.versionName} · ${formatSize(app.size)}$parts",
            headerIcon = Icons.Default.Android,
            headerTint = Category.APPS.color(),
            actions = actions,
            onDismiss = { menuTarget = null }
        )
    }
}

@Composable
private fun AppRow(app: AppInfoItem, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val icon: ImageBitmap? = remember(app.packageName) {
        try {
            ctx.packageManager.getApplicationIcon(app.packageName).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(cs.surface),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(40.dp))
            } else {
                Icon(Icons.Default.Android, contentDescription = null, tint = cs.primary)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                app.label,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "${app.versionName} · ${formatSize(app.size)}",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}
