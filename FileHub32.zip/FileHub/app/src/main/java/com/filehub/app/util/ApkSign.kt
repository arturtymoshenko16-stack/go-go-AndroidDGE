package com.filehub.app.util

import android.content.Context
import com.android.apksig.ApkSigner
import java.io.File
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec

/** Подпись APK ключом из assets (схемы v1+v2+v3). */
object ApkSign {

    fun sign(ctx: Context, input: File, output: File) {
        val keyBytes = ctx.assets.open("xcode_key.pk8").use { it.readBytes() }
        val certBytes = ctx.assets.open("xcode_cert.der").use { it.readBytes() }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(certBytes.inputStream()) as X509Certificate
        val cfg = ApkSigner.SignerConfig.Builder("xcode", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input)
            .setOutputApk(output)
            .setMinSdkVersion(26)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }
}
