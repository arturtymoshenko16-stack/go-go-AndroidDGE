package com.filehub.app.data

import android.content.Context
import java.io.File
import java.nio.charset.Charset
import java.util.zip.ZipFile

data class ZipItem(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val time: Long
)

object ZipTools {

    /** Имена в старых архивах часто в кодировке CP866 — пробуем её, если UTF-8 не подошла. */
    private fun open(zip: File): ZipFile {
        return try {
            ZipFile(zip)
        } catch (e: Exception) {
            ZipFile(zip, Charset.forName("IBM866"))
        }
    }

    /** Содержимое одного «уровня» архива: папки сверху, потом файлы. */
    fun list(zip: File, prefix: String): List<ZipItem> {
        return open(zip).use { zf ->
            val dirs = LinkedHashMap<String, ZipItem>()
            val files = ArrayList<ZipItem>()
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val full = entry.name
                if (!full.startsWith(prefix)) continue
                val rest = full.substring(prefix.length)
                if (rest.isEmpty()) continue
                val slash = rest.indexOf('/')
                if (slash >= 0) {
                    val dirName = rest.substring(0, slash)
                    if (dirName.isNotEmpty() && !dirs.containsKey(dirName)) {
                        dirs[dirName] = ZipItem(dirName, prefix + dirName + "/", true, 0L, entry.time)
                    }
                } else if (!entry.isDirectory) {
                    files.add(ZipItem(rest, full, false, entry.size, entry.time))
                }
            }
            dirs.values.sortedBy { it.name.lowercase() } + files.sortedBy { it.name.lowercase() }
        }
    }

    /**
     * Распаковывает запись (файл, папку с «/» на конце) или весь архив (entryPath пустой) в destDir.
     * Возвращает число распакованных файлов. Защищено от выхода за пределы destDir (zip-slip).
     */
    fun extract(zip: File, entryPath: String, destDir: File): Int {
        var count = 0
        destDir.mkdirs()
        val destCanon = destDir.canonicalPath

        var strip = 0
        if (entryPath.isNotEmpty()) {
            val parent = entryPath.trimEnd('/').substringBeforeLast('/', "")
            if (parent.isNotEmpty()) strip = parent.length + 1
        }

        open(zip).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val name = entry.name
                val match = entryPath.isEmpty() ||
                    name == entryPath ||
                    (entryPath.endsWith("/") && name.startsWith(entryPath))
                if (!match) continue
                if (name.length < strip) continue

                val out = File(destDir, name.substring(strip))
                val canon = out.canonicalPath
                if (canon != destCanon && !canon.startsWith(destCanon + File.separator)) continue

                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    zf.getInputStream(entry).use { input ->
                        out.outputStream().use { output -> input.copyTo(output) }
                    }
                    count++
                }
            }
        }
        return count
    }

    /** Распаковывает один файл во временную папку приложения для просмотра. */
    fun extractToCache(ctx: Context, zip: File, entryPath: String): File? {
        val root = File(ctx.cacheDir, "zipview")
        root.deleteRecursively()
        val dir = File(root, "e")
        val count = extract(zip, entryPath, dir)
        if (count == 0) return null
        return File(dir, entryPath.substringAfterLast('/'))
    }

    fun uniqueDir(parent: File, name: String): File {
        var dir = File(parent, name)
        var i = 1
        while (dir.exists()) {
            dir = File(parent, "$name ($i)")
            i++
        }
        return dir
    }
}
