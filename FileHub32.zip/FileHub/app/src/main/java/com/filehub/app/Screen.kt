package com.filehub.app

import com.filehub.app.data.Category
import java.io.File

sealed interface Screen {
    data object Home : Screen
    data object Clean : Screen
    data object Settings : Screen
    data object Search : Screen
    data object Large : Screen
    data object Apps : Screen
    data class Browser(val dir: File) : Screen
    data class CategoryList(val category: Category) : Screen
    data class Viewer(
        val file: File,
        val asText: Boolean = false,
        val readOnly: Boolean = false
    ) : Screen
    data class Archive(val zip: File, val prefix: String = "") : Screen
}
