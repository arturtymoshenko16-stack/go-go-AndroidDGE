# FileHub Arctic Fox project

This is a minimal Android project using an older Arctic Fox-era toolchain:
- Android Gradle Plugin 7.0.4
- Gradle 7.0.2
- JDK 11
- Android SDK 30 / Build Tools 30.0.3

## Build APK on GitHub
1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Open the **Actions** tab.
4. Run **Build FileHub APK** (or push to `main` / `master`).
5. Open the completed workflow run and download the `FileHub-ArcticFox-debug` artifact.

## Important limitation
This is a starter app project and GitHub Actions workflow. It builds this FileHub sample app into an APK.
It does **not** bundle Android Studio, and it does not yet build arbitrary Android projects from ZIP files on the Android device.
Running a full Android build toolchain directly on an Android tablet requires additional porting and compatibility work.
