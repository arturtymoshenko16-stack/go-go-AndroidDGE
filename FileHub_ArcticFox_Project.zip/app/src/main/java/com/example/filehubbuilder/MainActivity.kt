package com.example.filehubbuilder

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = "FileHub APK Builder"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }

        val info = TextView(this).apply {
            text = "\nArctic Fox project template\n\nThis starter app can be built into an APK by GitHub Actions.\n\nIt does not yet compile arbitrary Android ZIP projects on the device."
            textSize = 16f
            gravity = Gravity.CENTER
        }

        root.addView(title)
        root.addView(info)
        setContentView(root)
    }
}
