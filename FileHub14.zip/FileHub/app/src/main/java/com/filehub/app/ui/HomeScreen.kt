@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.Category
import com.filehub.app.data.StorageInfo
import com.filehub.app.data.formatSize
import com.filehub.app.util.FileActions

private class Tile(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scan = vm.scan
    val storage = vm.storage
    val sizes = remember(scan, storage) { displaySizes(scan?.sizes.orEmpty(), storage) }
    val recent = scan?.recent.orEmpty()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            HomeHeader(
                onMenu = { vm.openDrawer() },
                onSearch = { vm.navigate(Screen.Search) },
                onSettings = { vm.navigate(Screen.Settings) }
            )
        }
        item {
            StorageCard(
                storage = storage,
                sizes = sizes,
                ready = scan != null,
                scanning = vm.scanning,
                onClean = { vm.navigate(Screen.Clean) }
            )
        }
        item {
            Column {
                SectionTitle("Категории")
                Spacer(Modifier.height(10.dp))
                CategoryGrid(vm)
            }
        }
        if (vm.showRecent && recent.isNotEmpty()) {
            item { SectionTitle("Недавние") }
            items(recent, key = { it.path }) { f ->
                FileRow(
                    file = f,
                    selected = false,
                    selectionMode = false,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            openFile(vm, ctx, f)
                        }
                )
            }
        }
    }
}

private fun displaySizes(scanned: Map<Category, Long>, storage: StorageInfo): Map<Category, Long> {
    val withoutOther = scanned.filterKeys { it != Category.OTHER }
    val known = withoutOther.values.sum()
    val other = (storage.used - known).coerceAtLeast(0L)
    return withoutOther + (Category.OTHER to other)
}

@Composable
private fun HomeHeader(onMenu: () -> Unit, onSearch: () -> Unit, onSettings: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            Icons.Default.Folder,
            contentDescription = null,
            tint = cs.primary,
            modifier = Modifier.size(30.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            "Android XCODE",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = cs.onBackground,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onSearch) {
            Icon(Icons.Default.Search, contentDescription = "Поиск", tint = cs.onBackground)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = cs.onBackground)
        }
        IconButton(onClick = onMenu) {
            Icon(Icons.Default.Menu, contentDescription = "Меню", tint = cs.onBackground)
        }
    }
}

@Composable
private fun StorageCard(
    storage: StorageInfo,
    sizes: Map<Category, Long>,
    ready: Boolean,
    scanning: Boolean,
    onClean: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Внутренняя память",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "Всего: ${formatSize(storage.total)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                StorageDonut(storage = storage, sizes = sizes)
                Spacer(Modifier.width(14.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    for (cat in Category.values()) {
                        val value = if (!ready && cat != Category.OTHER) "—"
                        else formatSize(sizes[cat] ?: 0L)
                        LegendRow(cat.color(), cat.label, value)
                    }
                    LegendRow(FreeColor, "Свободно", formatSize(storage.free))
                }
            }
            Spacer(Modifier.height(16.dp))
            FilledTonalButton(onClick = onClean, modifier = Modifier.fillMaxWidth()) {
                Text("Освободить место")
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = cs.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
            if (scanning) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(4.dp))
                Text(
                    "Анализ памяти…",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun LegendRow(color: Color, label: String, value: String) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurface,
            maxLines = 1
        )
    }
}

@Composable
private fun CategoryGrid(vm: MainViewModel) {
    val tiles = listOf(
        Tile("Приложения", Icons.Default.Android, Category.APPS.color()) {
            vm.navigate(Screen.Apps)
        },
        Tile("Изображения", Icons.Default.Image, Category.IMAGES.color()) {
            vm.navigate(Screen.CategoryList(Category.IMAGES))
        },
        Tile("Видео", Icons.Default.Movie, Category.VIDEOS.color()) {
            vm.navigate(Screen.CategoryList(Category.VIDEOS))
        },
        Tile("Музыка", Icons.Default.MusicNote, Category.MUSIC.color()) {
            vm.navigate(Screen.CategoryList(Category.MUSIC))
        },
        Tile("Документы", Icons.Default.Description, Category.DOCUMENTS.color()) {
            vm.navigate(Screen.CategoryList(Category.DOCUMENTS))
        },
        Tile("Загрузки", Icons.Default.Download, DownloadsColor) {
            vm.navigate(Screen.Browser(vm.repo.downloads))
        }
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        for (pair in tiles.chunked(2)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (tile in pair) {
                    TileButton(tile, Modifier.weight(1f))
                }
            }
        }
        TileButton(
            Tile("Все файлы", Icons.Default.Folder, FolderColor) {
                vm.navigate(Screen.Browser(vm.repo.root))
            },
            Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun TileButton(tile: Tile, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(cs.surface)
            .clickable(onClick = tile.onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(tile.icon, contentDescription = null, tint = tile.color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            tile.title,
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
