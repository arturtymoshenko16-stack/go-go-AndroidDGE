package com.filehub.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.filehub.app.data.FileTypes
import java.io.File

object FileActions {

    private fun uriOf(ctx: Context, file: File): Uri =
        FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)

    fun toast(ctx: Context, text: String) {
        Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
    }

    fun open(ctx: Context, file: File) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uriOf(ctx, file), FileTypes.mimeOf(file))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
        } catch (e: Exception) {
            toast(ctx, "Нет приложения для открытия этого файла")
        }
    }

    fun share(ctx: Context, files: List<File>) {
        val list = files.filter { it.isFile }
        if (list.isEmpty()) {
            toast(ctx, "Отправлять можно только файлы")
            return
        }
        try {
            val intent = if (list.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = FileTypes.mimeOf(list[0])
                    putExtra(Intent.EXTRA_STREAM, uriOf(ctx, list[0]))
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "*/*"
                    putParcelableArrayListExtra(
                        Intent.EXTRA_STREAM,
                        ArrayList(list.map { uriOf(ctx, it) })
                    )
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(intent, "Отправить")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(chooser)
        } catch (e: Exception) {
            toast(ctx, "Не удалось отправить файл")
        }
    }

    /** Отправляет один файл прямо в указанное приложение (например, Termux сохранит его в ~/downloads). */
    fun sendToPackage(ctx: Context, file: File, pkg: String): Boolean {
        if (!file.isFile) {
            toast(ctx, "Можно отправить только файл")
            return false
        }
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = FileTypes.mimeOf(file)
                setPackage(pkg)
                putExtra(Intent.EXTRA_STREAM, uriOf(ctx, file))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            toast(ctx, "Приложение не найдено или не принимает файлы")
            false
        }
    }
}
