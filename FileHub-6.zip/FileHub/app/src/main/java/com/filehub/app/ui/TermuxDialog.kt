@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.filehub.app.util.FileActions
import com.filehub.app.util.TermuxTools
import java.io.File

/** «Установить в Termux»: распаковать zip командой unzip внутри Termux, при желании запустить install.sh. */
@Composable
fun TermuxUnzipDialog(zip: File, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var dest by remember { mutableStateOf("~/" + zip.nameWithoutExtension) }
    var runInstall by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Установить в Termux") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Архив «${zip.name}» будет распакован командой unzip внутри Termux.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = dest,
                    onValueChange = { dest = it },
                    label = { Text("Папка в Termux") },
                    supportingText = { Text("~ — домашняя папка Termux") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { runInstall = !runInstall },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = runInstall, onCheckedChange = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Затем запустить install.sh или setup.sh, если есть",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                TextButton(onClick = { showHelp = true }) {
                    Text("Первая настройка Termux")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (TermuxTools.runWithToast(ctx, TermuxTools.unzipScript(zip, dest, runInstall))) {
                    onDismiss()
                } else if (!TermuxTools.hasPermission(ctx) && TermuxTools.isInstalled(ctx)) {
                    showHelp = true
                }
            }) { Text("Установить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )

    if (showHelp) {
        TermuxHelpDialog(onDismiss = { showHelp = false })
    }
}

@Composable
fun TermuxHelpDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Первая настройка Termux") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Делается один раз.\n\n" +
                        "1. Установите Termux (лучше с F-Droid или GitHub).\n\n" +
                        "2. Нажмите «Копировать команду», откройте Termux, вставьте команду и нажмите Enter. " +
                        "Она включает внешний доступ, ставит unzip и запросит доступ к памяти — разрешите.\n\n" +
                        "3. Вернитесь сюда и разрешите приложению «Запуск команд в среде Termux» " +
                        "(окно появится при первой установке; иначе: Настройки → Приложения → Android XCODE → Разрешения).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurface
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                clipboard.setText(AnnotatedString(TermuxTools.SETUP_COMMAND))
                FileActions.toast(ctx, "Команда скопирована")
            }) { Text("Копировать команду") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { TermuxTools.openTermux(ctx) }) { Text("Открыть Termux") }
                TextButton(onClick = onDismiss) { Text("Закрыть") }
            }
        }
    )
}
