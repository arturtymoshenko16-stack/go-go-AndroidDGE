package com.filehub.app.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File

enum class TermuxResult { OK, NOT_INSTALLED, NO_PERMISSION, ERROR }

/**
 * Связка с Termux через его официальный интерфейс RUN_COMMAND.
 * Требует: Termux установлен, в ~/.termux/termux.properties включено allow-external-apps=true,
 * а нашему приложению выдано разрешение «Запуск команд в среде Termux».
 */
object TermuxTools {
    const val PKG = "com.termux"
    const val PERM = "com.termux.permission.RUN_COMMAND"
    private const val HOME = "/data/data/com.termux/files/home"
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"

    /** Команда первой настройки: вставляется в Termux один раз. */
    const val SETUP_COMMAND =
        "mkdir -p ~/.termux; " +
            "grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null || " +
            "echo 'allow-external-apps=true' >> ~/.termux/termux.properties; " +
            "termux-reload-settings; pkg install -y unzip; termux-setup-storage"

    fun isInstalled(ctx: Context): Boolean {
        return try {
            ctx.packageManager.getPackageInfo(PKG, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hasPermission(ctx: Context): Boolean {
        return ContextCompat.checkSelfPermission(ctx, PERM) == PackageManager.PERMISSION_GRANTED
    }

    /** Экранирование строки для оболочки (одинарные кавычки). */
    fun shq(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    /** Путь внутри Termux: «~» и «$HOME» раскрываются в домашнюю папку Termux. */
    private fun shDest(dest: String): String {
        var d = dest.trim().ifEmpty { "~" }
        if (d == "~") d = "\$HOME"
        d = d.replaceFirst("~/", "\$HOME/")
        return if (d.startsWith("\$HOME")) {
            "\"\$HOME\"" + shq(d.removePrefix("\$HOME"))
        } else {
            shq(d)
        }
    }

    fun unzipScript(zip: File, dest: String, runInstall: Boolean): String {
        val d = shDest(dest)
        val sb = StringBuilder()
        sb.append("mkdir -p $d && unzip -o ${shq(zip.path)} -d $d && echo && echo 'Распаковано в:' $d")
        if (runInstall) {
            sb.append(
                " && cd $d && for f in install.sh setup.sh; do " +
                    "if [ -f \"\$f\" ]; then echo \"Запуск \$f\"; bash \"\$f\"; break; fi; done"
            )
        }
        return sb.toString()
    }

    fun run(ctx: Context, script: String): TermuxResult {
        if (!isInstalled(ctx)) return TermuxResult.NOT_INSTALLED
        if (!hasPermission(ctx)) {
            (ctx as? Activity)?.let {
                ActivityCompat.requestPermissions(it, arrayOf(PERM), 77)
            }
            return TermuxResult.NO_PERMISSION
        }
        val intent = Intent().apply {
            setClassName(PKG, "com.termux.app.RunCommandService")
            action = "com.termux.RUN_COMMAND"
            putExtra("com.termux.RUN_COMMAND_PATH", BASH)
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", "$script; echo; echo '[Android XCODE] Готово'"))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
            putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
        }
        return try {
            ctx.startForegroundService(intent)
            TermuxResult.OK
        } catch (e: SecurityException) {
            TermuxResult.NO_PERMISSION
        } catch (e: Exception) {
            TermuxResult.ERROR
        }
    }

    /** Запускает команду и сам показывает подсказку, если что-то не готово. Возвращает true при успехе. */
    fun runWithToast(ctx: Context, script: String): Boolean {
        return when (run(ctx, script)) {
            TermuxResult.OK -> true
            TermuxResult.NOT_INSTALLED -> {
                FileActions.toast(ctx, "Termux не установлен")
                false
            }
            TermuxResult.NO_PERMISSION -> {
                FileActions.toast(
                    ctx,
                    "Разрешите запуск команд Termux и повторите. Если окна нет: Настройки → Приложения → Android XCODE → Разрешения"
                )
                false
            }
            TermuxResult.ERROR -> {
                FileActions.toast(
                    ctx,
                    "Termux не принял команду. Выполните первую настройку (allow-external-apps)"
                )
                false
            }
        }
    }

    fun openTermux(ctx: Context) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(PKG)
        if (intent == null) {
            FileActions.toast(ctx, "Termux не установлен")
        } else {
            ctx.startActivity(intent)
        }
    }
}
