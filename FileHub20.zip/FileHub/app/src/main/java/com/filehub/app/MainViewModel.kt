package com.filehub.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.filehub.app.data.FileRepository
import com.filehub.app.data.ZipTools
import com.filehub.app.util.ApkBuild
import com.filehub.app.util.ApkResult
import com.filehub.app.util.Toolchain
import com.filehub.app.data.ScanResult
import com.filehub.app.data.SortMode
import com.filehub.app.data.StorageInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val repo = FileRepository()
    private val prefs = app.getSharedPreferences("filehub", Context.MODE_PRIVATE)

    // Настройки
    var darkTheme by mutableStateOf(prefs.getBoolean("dark", true))
    var showHidden by mutableStateOf(prefs.getBoolean("hidden", false))
    var showRecent by mutableStateOf(prefs.getBoolean("recent", true))
    var sort by mutableStateOf(
        runCatching { SortMode.valueOf(prefs.getString("sort", SortMode.NAME.name) ?: "NAME") }
            .getOrDefault(SortMode.NAME)
    )

    var toolchainPath by mutableStateOf(
        prefs.getString("toolchain_path", "/storage/emulated/0/Download/ndk_arm64.tar.gz") ?: ""
    )

    fun setToolchainPath(value: String) {
        toolchainPath = value
        prefs.edit().putString("toolchain_path", value).apply()
    }

    fun setDark(value: Boolean) {
        darkTheme = value
        prefs.edit().putBoolean("dark", value).apply()
    }

    fun setHidden(value: Boolean) {
        showHidden = value
        prefs.edit().putBoolean("hidden", value).apply()
    }

    fun setRecent(value: Boolean) {
        showRecent = value
        prefs.edit().putBoolean("recent", value).apply()
    }

    fun changeSort(value: SortMode) {
        sort = value
        prefs.edit().putString("sort", value.name).apply()
    }

    // Навигация
    val backStack = mutableStateListOf<Screen>(Screen.Home)
    val current: Screen get() = backStack.last()

    var drawerRequest by mutableIntStateOf(0)
    fun openDrawer() { drawerRequest++ }

    fun goHome() {
        backStack.clear()
        backStack.add(Screen.Home)
    }

    fun openFolder(dir: File) {
        backStack.add(Screen.Browser(dir))
    }

    fun buildAuto(folder: File, onDone: (ApkResult) -> Unit) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { ApkBuild.auto(ctx, folder) }
            tick++
            refreshAll()
            onDone(r)
        }
    }

    fun navigate(screen: Screen) {
        backStack.add(screen)
    }

    fun back() {
        if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
    }

    // Данные
    var storage by mutableStateOf(StorageInfo())
    var scan by mutableStateOf<ScanResult?>(null)
    var scanning by mutableStateOf(false)
    var tick by mutableIntStateOf(0)

    fun refreshAll() {
        storage = repo.storageInfo()
        viewModelScope.launch {
            scanning = true
            try {
                scan = repo.scan()
            } finally {
                scanning = false
            }
        }
    }

    private fun afterChange() {
        tick++
        refreshAll()
    }

    // Буфер обмена
    var clipboard by mutableStateOf<List<File>>(emptyList())
    var clipboardMove by mutableStateOf(false)

    fun putToClipboard(files: List<File>, move: Boolean) {
        clipboard = files.toList()
        clipboardMove = move
    }

    fun clearClipboard() {
        clipboard = emptyList()
    }

    // Распаковка ZIP в папку рядом с архивом. n = -1 при ошибке.
    fun extractZip(zip: File, entry: String, onDone: (Int, File) -> Unit) {
        viewModelScope.launch {
            val dest = ZipTools.uniqueDir(zip.parentFile ?: repo.root, zip.nameWithoutExtension)
            val n = withContext(Dispatchers.IO) {
                runCatching { ZipTools.extract(zip, entry, dest) }.getOrDefault(-1)
            }
            tick++
            refreshAll()
            onDone(n, dest)
        }
    }

    // Папка → подписанный APK
    fun buildApk(folder: File, onDone: (ApkResult) -> Unit) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { ApkBuild.build(ctx, folder) }
            tick++
            refreshAll()
            onDone(r)
        }
    }

    fun installToolchain(archive: File, onDone: (Int, String?) -> Unit) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            var err: String? = null
            val n = withContext(Dispatchers.IO) {
                try { Toolchain.install(ctx, archive) } catch (e: Throwable) { err = e.message ?: e.javaClass.simpleName; -1 }
            }
            onDone(n, err)
        }
    }

    fun buildProject(folder: File, onDone: (ApkResult) -> Unit) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { ApkBuild.buildProject(ctx, folder) }
            tick++
            refreshAll()
            onDone(r)
        }
    }

    // Файловые операции
    fun deleteFiles(files: List<File>, onDone: (Int) -> Unit) {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { repo.delete(files) }
            afterChange()
            onDone(n)
        }
    }

    fun rename(file: File, newName: String): Boolean {
        val ok = repo.rename(file, newName)
        if (ok) tick++
        return ok
    }

    fun createFolder(parent: File, name: String): Boolean {
        val ok = repo.createFolder(parent, name)
        if (ok) tick++
        return ok
    }

    fun paste(target: File, onDone: (Int) -> Unit) {
        val files = clipboard
        val move = clipboardMove
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { repo.paste(files, target, move) }
            if (move) clearClipboard()
            afterChange()
            onDone(n)
        }
    }
}
