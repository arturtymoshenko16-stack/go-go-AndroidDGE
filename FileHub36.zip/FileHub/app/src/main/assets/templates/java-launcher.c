/* Запускатель java на базе libjli.so из JDK (как main.c в OpenJDK). */
extern int JLI_Launch(int argc, char **argv,
                      int jargc, const char **jargv,
                      int appclassc, const char **appclassv,
                      const char *fullversion, const char *dotversion,
                      const char *pname, const char *lname,
                      unsigned char javaargs, unsigned char cpwildcard,
                      unsigned char javaw, int ergo);

int main(int argc, char **argv) {
    const char *jargs[1] = {0};
    const char *app[1] = {0};
    return JLI_Launch(argc, argv, 0, jargs, 0, app,
                      "17.0.21", "17.0.21", "java", "openjdk",
                      0, 1, 0, 0);
}
