#!/system/bin/sh
# Строит bin/java и bin/javac для JDK без bin/ (например, nexira jdk-17-android-aarch64.zip).
# Вызов: sh setup-java.sh <любой> <любой>
LIBJLI=$(find "$TOOLCHAIN" -name libjli.so 2>/dev/null | head -n 1)
[ -z "$LIBJLI" ] && { echo "В наборе нет libjli.so (сначала установите JDK .zip)"; exit 1; }
LIBDIR=$(dirname "$LIBJLI")
JDK=$(dirname "$LIBDIR")
CLANG=$(find "$TOOLCHAIN" -name 'aarch64-linux-android*-clang' 2>/dev/null | sort | tail -n 1)
[ -z "$CLANG" ] && { echo "В наборе нет clang (NDK)"; exit 1; }
SRC="$TOOLCHAIN/java-launcher.c"
[ -f "$SRC" ] || { echo "Нет $SRC — нажмите «Обновить шаблоны скриптов»"; exit 1; }
mkdir -p "$JDK/bin"
"$CLANG" -O2 -o "$JDK/bin/java" "$SRC" -L"$LIBDIR" -ljli -Wl,-rpath,'$ORIGIN/../lib' || exit 1
chmod +x "$JDK/bin/java"
cat > "$JDK/bin/javac" <<'EOS'
#!/system/bin/sh
DIR=$(cd "$(dirname "$0")" && pwd)
exec "$DIR/java" -m jdk.compiler/com.sun.tools.javac.Main "$@"
EOS
chmod +x "$JDK/bin/javac"
echo "Готово: $JDK/bin/java и $JDK/bin/javac"
"$JDK/bin/java" -version 2>&1 | head -n 3
