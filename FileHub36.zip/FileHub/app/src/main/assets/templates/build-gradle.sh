#!/system/bin/sh
# Шаблон: сборка Gradle-проекта (gradle assembleDebug) на телефоне.
# Вызов: sh build-gradle.sh <корень_gradle_проекта> <выход.apk>
# Нужно в наборе: JDK 17 для aarch64 (bin/java), Gradle (gradle-8.7-bin.zip), SDK (platforms/android-34), aapt2 для aarch64.
# Нужен интернет: Gradle скачает плагины и библиотеки.
PROJECT="$1"
OUT="$2"

JAVA=$(find "$TOOLCHAIN" -type f -name java 2>/dev/null | grep '/bin/java$' | head -n 1)
[ -z "$JAVA" ] && JAVA=$(command -v java)
[ -z "$JAVA" ] && { echo "В наборе нет java (нужен JDK 17 для aarch64)"; exit 1; }
chmod +x "$JAVA" 2>/dev/null
export JAVA_HOME=$(dirname "$(dirname "$JAVA")")

LAUNCHER=$(find "$TOOLCHAIN" -name 'gradle-launcher-*.jar' 2>/dev/null | head -n 1)
[ -z "$LAUNCHER" ] && { echo "В наборе нет Gradle (добавьте gradle-8.7-bin.zip)"; exit 1; }

AAPT2=$(find "$TOOLCHAIN" -type f -name aapt2 2>/dev/null | head -n 1)
[ -z "$AAPT2" ] && { echo "В наборе нет aapt2 для aarch64"; exit 1; }
chmod +x "$AAPT2" 2>/dev/null

PLAT=$(find "$TOOLCHAIN" -type d -name platforms 2>/dev/null | head -n 1)
[ -z "$PLAT" ] && { echo "В наборе нет папки platforms (Android SDK)"; exit 1; }
export ANDROID_HOME=$(dirname "$PLAT")
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GRADLE_USER_HOME="$HOME/.gradle"

cd "$PROJECT" || exit 1
echo "sdk.dir=$ANDROID_HOME" > local.properties

"$JAVA" -Xmx1536m -Dorg.gradle.appname=gradle -classpath "$LAUNCHER" \
  org.gradle.launcher.GradleMain assembleDebug --no-daemon --console=plain \
  -Pandroid.aapt2FromMavenOverride="$AAPT2" || exit 1

APK=$(find "$PROJECT" -path '*build/outputs/apk/debug/*.apk' 2>/dev/null | head -n 1)
[ -z "$APK" ] && { echo "Gradle завершился, но debug APK не найден"; exit 1; }
cp "$APK" "$OUT"
echo "Готово: $OUT"
