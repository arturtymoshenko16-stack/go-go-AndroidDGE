package com.filehub.app.util

import android.content.Context
import android.system.Os
import java.io.File
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

/**
 * Набор инструментов сборки (tar.gz с aarch64-программами).
 * Соглашение: в архиве есть build.sh, вызывается как
 *   sh build.sh <папка_проекта> <выходной_unsigned.apk>
 * Переменные окружения: TOOLCHAIN (корень набора), HOME, TMPDIR.
 */
object Toolchain {

    fun dir(ctx: Context) = File(ctx.filesDir, "toolchain")

    fun root(ctx: Context): File? {
        val d = dir(ctx)
        if (File(d, "build.sh").isFile) return d
        return d.listFiles()?.firstOrNull { it.isDirectory && File(it, "build.sh").isFile }
    }

    /** Что лежит в установленном наборе: скрипты и найденные программы. */
    fun summary(ctx: Context): String {
        val d = dir(ctx)
        val root = root(ctx)
        if (!d.isDirectory || (d.list()?.isEmpty() != false)) return "Набор не установлен."
        val base = root ?: d
        fun has(name: String) = base.walkTopDown().maxDepth(8).any { it.isFile && it.name == name }
        fun mark(ok: Boolean) = if (ok) "есть" else "нет"
        val clang = base.walkTopDown().maxDepth(8).any { it.name.startsWith("aarch64-linux-android") && it.name.endsWith("-clang") }
        val top = d.list()?.sorted()?.take(8)?.joinToString(", ") ?: ""
        return "Корень: ${base.name}\nВ папке: $top\n" +
            "build.sh: ${mark(File(base, "build.sh").isFile)}, build-so.sh: ${mark(File(base, "build-so.sh").isFile)}\n" +
            "clang: ${mark(clang)}, aapt2: ${mark(has("aapt2"))}, android.jar: ${mark(has("android.jar"))}\n" +
            "d8: ${mark(has("d8") || has("d8.jar") || has("r8.jar"))}, javac: ${mark(has("javac"))}, java: ${mark(has("java"))}\n" +
            "Приложение на C++ (NativeActivity): " +
            (if (clang && has("aapt2") && has("android.jar")) "можно собрать" else "не хватает инструментов") + "\n" +
            "Gradle: " +
            (if (base.walkTopDown().maxDepth(8).any { it.name.startsWith("gradle-launcher-") }) "есть" else "нет") + "\n" +
            "Java-проект: " +
            (if (has("javac") && has("java") && (has("d8") || has("d8.jar"))) "можно собрать" else "нужны JDK (javac, java) и d8")
    }

    /** Кладёт шаблоны build.sh / build-so.sh в набор, если их там нет. Возвращает список добавленных. */
    fun addTemplates(ctx: Context): List<String> {
        val base = root(ctx) ?: dir(ctx).takeIf { it.isDirectory } ?: return emptyList()
        val added = ArrayList<String>()
        for (name in listOf("build.sh", "build-so.sh", "build-native.sh", "build-gradle.sh", "setup-java.sh", "java-launcher.c")) {
            val target = File(base, name)
            ctx.assets.open("templates/$name").use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            target.setExecutable(true, false)
            added.add(name)
        }
        return added
    }

    fun isTarGz(f: File): Boolean {
        val n = f.name.lowercase()
        return n.endsWith(".tar.gz") || n.endsWith(".tgz")
    }

    fun isToolArchive(f: File): Boolean = isTarGz(f) || f.name.lowercase().endsWith(".zip")

    fun clear(ctx: Context) {
        dir(ctx).deleteRecursively()
    }

    /** Распаковка ZIP в набор (добавляется к уже установленному). */
    private fun installZip(archive: File, dest: File): Int {
        val destPath = dest.canonicalPath + File.separator
        var count = 0
        java.util.zip.ZipFile(archive).use { zf ->
            for (e in zf.entries()) {
                val target = File(dest, e.name)
                if (!target.canonicalPath.plus(if (e.isDirectory) File.separator else "").startsWith(destPath)) continue
                if (e.isDirectory) { target.mkdirs(); continue }
                target.parentFile?.mkdirs()
                zf.getInputStream(e).use { i -> target.outputStream().use { o -> i.copyTo(o) } }
                target.setReadable(true, false)
                target.setExecutable(true, false)
                count++
            }
        }
        return count
    }

    private fun readFully(ins: InputStream, buf: ByteArray, len: Int): Boolean {
        var off = 0
        while (off < len) {
            val n = ins.read(buf, off, len - off)
            if (n < 0) return false
            off += n
        }
        return true
    }

    private fun str(b: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && b[end].toInt() != 0) end++
        return String(b, off, end - off, Charsets.UTF_8)
    }

    private fun octal(b: ByteArray, off: Int, len: Int): Long =
        str(b, off, len).trim().ifEmpty { "0" }.toLong(8)

    /** Распаковка tar.gz с правами и симлинками. Возвращает число файлов. */
    fun install(ctx: Context, archive: File): Int {
        val dest = dir(ctx)
        dest.mkdirs()
        if (archive.name.lowercase().endsWith(".zip")) return installZip(archive, dest)
        val destPath = dest.canonicalPath + File.separator
        var count = 0
        var longName: String? = null
        val hdr = ByteArray(512)
        GZIPInputStream(archive.inputStream().buffered(1 shl 16)).use { ins ->
            while (true) {
                if (!readFully(ins, hdr, 512)) break
                if (hdr.all { it.toInt() == 0 }) break
                var name = str(hdr, 0, 100)
                val prefix = str(hdr, 345, 155)
                if (prefix.isNotEmpty() && str(hdr, 257, 5) == "ustar") name = "$prefix/$name"
                val size = octal(hdr, 124, 12)
                val type = hdr[156].toInt().toChar()
                val mode = octal(hdr, 100, 8).toInt()
                val link = str(hdr, 157, 100)
                val padded = (size + 511) / 512 * 512

                if (type == 'L' || type == 'x' || type == 'g') {
                    val data = ByteArray(size.toInt())
                    readFully(ins, data, data.size)
                    ins.skip(padded - size)
                    if (type == 'L') longName = str(data, 0, data.size)
                    if (type == 'x') {
                        String(data, Charsets.UTF_8).lines().forEach {
                            val i = it.indexOf(" path=")
                            if (i >= 0) longName = it.substring(i + 6)
                        }
                    }
                    continue
                }
                if (longName != null) { name = longName!!; longName = null }
                val target = File(dest, name)
                if (!target.canonicalPath.plus(if (type == '5') File.separator else "").startsWith(destPath)) {
                    ins.skip(padded); continue
                }
                when (type) {
                    '5' -> target.mkdirs()
                    '2' -> {
                        target.parentFile?.mkdirs()
                        runCatching { target.delete(); Os.symlink(link, target.path) }
                        ins.skip(padded)
                    }
                    '1' -> {
                        target.parentFile?.mkdirs()
                        val src = File(dest, link)
                        if (src.isFile) src.copyTo(target, overwrite = true)
                        if (mode and 0x49 != 0) target.setExecutable(true, false)
                    }
                    '0', '\u0000' -> {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { o ->
                            var left = size
                            val buf = ByteArray(65536)
                            while (left > 0) {
                                val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                                if (n < 0) break
                                o.write(buf, 0, n); left -= n
                            }
                        }
                        ins.skip(padded - size)
                        target.setReadable(true, false)
                        if (mode and 0x49 != 0) target.setExecutable(true, false)
                        count++
                    }
                    else -> ins.skip(padded)
                }
            }
        }
        return count
    }

    /** Запускает build.sh. Возвращает (код выхода, последние строки лога). */
    fun run(ctx: Context, project: File, out: File): Pair<Int, String> =
        runScript(ctx, "build.sh", project, out)

    /** Запускает скрипт из набора: sh <script> <проект> <выход>. */
    fun runScript(ctx: Context, script: String, project: File, out: File): Pair<Int, String> {
        val root = root(ctx) ?: return -1 to "Инструменты не установлены"
        if (!File(root, script).isFile) return -3 to "В наборе инструментов нет файла $script"
        File(root, script).setExecutable(true, false)
        val pb = ProcessBuilder("/system/bin/sh", File(root, script).path, project.path, out.path)
            .directory(project)
            .redirectErrorStream(true)
        pb.environment().apply {
            put("TOOLCHAIN", root.path)
            put("HOME", ctx.filesDir.path)
            put("TMPDIR", ctx.cacheDir.path)
            put("PATH", File(root, "bin").path + ":" + (get("PATH") ?: "/system/bin"))
        }
        val p = pb.start()
        val tail = ArrayDeque<String>()
        val reader = Thread {
            p.inputStream.bufferedReader().forEachLine {
                tail.addLast(it); if (tail.size > 40) tail.removeFirst()
            }
        }
        reader.start()
        if (!p.waitFor(90, TimeUnit.MINUTES)) { p.destroyForcibly(); return -2 to "Таймаут сборки" }
        reader.join(2000)
        return p.exitValue() to tail.joinToString("\n")
    }
}
