package com.filehub.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.filehub.app.data.Category

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFF9800),
    onPrimary = Color(0xFF1A1A1A),
    secondary = Color(0xFFFFB74D),
    background = Color(0xFF14181D),
    onBackground = Color(0xFFE8EAED),
    surface = Color(0xFF1E242C),
    onSurface = Color(0xFFE8EAED),
    surfaceVariant = Color(0xFF2A323C),
    onSurfaceVariant = Color(0xFFA9B1BB),
    error = Color(0xFFFF6B6B)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFE67E00),
    onPrimary = Color.White,
    secondary = Color(0xFFFB8C00),
    background = Color(0xFFF4F6F8),
    onBackground = Color(0xFF1B1F24),
    surface = Color.White,
    onSurface = Color(0xFF1B1F24),
    surfaceVariant = Color(0xFFE6EAEE),
    onSurfaceVariant = Color(0xFF5B6570),
    error = Color(0xFFD32F2F)
)

@Composable
fun FileHubTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}

val FreeColor = Color(0xFF90A4AE)
val DownloadsColor = Color(0xFF42A5F5)
val FolderColor = Color(0xFFFFB300)

fun Category.color(): Color = when (this) {
    Category.APPS -> Color(0xFFEC407A)
    Category.IMAGES -> Color(0xFFBA68C8)
    Category.VIDEOS -> Color(0xFF26C6DA)
    Category.MUSIC -> Color(0xFF7E57C2)
    Category.DOCUMENTS -> Color(0xFF66BB6A)
    Category.OTHER -> Color(0xFF78909C)
}
