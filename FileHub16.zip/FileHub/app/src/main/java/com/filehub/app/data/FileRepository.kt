package com.filehub.app.data

import android.os.Environment
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.PriorityQueue

data class StorageInfo(val total: Long = 0L, val free: Long = 0L) {
    val used: Long get() = (total - free).coerceAtLeast(0L)
    val usedPercent: Int get() = if (total > 0) ((used * 100) / total).toInt() else 0
}

data class ScanResult(
    val sizes: Map<Category, Long>,
    val large: List<File>,
    val largeCount: Int,
    val largeSize: Long,
    val recent: List<File>,
    val downloads: List<File>,
    val downloadsSize: Long
)

class FileRepository {

    val root: File = Environment.getExternalStorageDirectory()
    val downloads: File =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

    fun storageInfo(): StorageInfo {
        return try {
            val stat = StatFs(root.path)
            StorageInfo(stat.totalBytes, stat.availableBytes)
        } catch (e: Exception) {
            StorageInfo()
        }
    }

    /** Содержимое папки: сначала папки, затем файлы. */
    fun list(dir: File, showHidden: Boolean, sort: SortMode): List<File> {
        val items = dir.listFiles()?.toList().orEmpty()
            .filter { showHidden || !it.name.startsWith(".") }
        val order: Comparator<File> = when (sort) {
            SortMode.NAME -> compareBy<File> { it.name.lowercase() }
            SortMode.SIZE -> compareByDescending<File> { if (it.isFile) it.length() else -1L }
            SortMode.DATE -> compareByDescending<File> { it.lastModified() }
        }
        return items.sortedWith(compareByDescending<File> { it.isDirectory }.then(order))
    }

    private fun walk(base: File): Sequence<File> {
        return base.walkTopDown()
            .onEnter { dir ->
                !dir.name.startsWith(".") &&
                    !(dir.name == "Android" && dir.parentFile == root)
            }
            .onFail { _, _ -> }
    }

    /** Один проход по памяти: размеры по категориям, крупные файлы, недавние, загрузки. */
    suspend fun scan(): ScanResult = withContext(Dispatchers.IO) {
        val sizes = HashMap<Category, Long>()
        val large = ArrayList<Pair<Long, File>>()
        val recent = PriorityQueue<Pair<Long, File>>(compareBy<Pair<Long, File>> { it.first })

        walk(root).forEach { f ->
            if (!f.isFile || f.name.startsWith(".")) return@forEach
            val len = f.length()
            val cat = FileTypes.categoryOf(f)
            sizes[cat] = (sizes[cat] ?: 0L) + len
            if (len >= LARGE_MIN) large.add(len to f)

            val mod = f.lastModified()
            if (recent.size < RECENT_COUNT) {
                recent.add(mod to f)
            } else if (mod > recent.peek()!!.first) {
                recent.poll()
                recent.add(mod to f)
            }
        }

        val downloadFiles = downloads.listFiles()
            ?.filter { it.isFile && !it.name.startsWith(".") }
            ?.sortedByDescending { it.lastModified() }
            .orEmpty()

        ScanResult(
            sizes = sizes,
            large = large.sortedByDescending { it.first }.take(MAX_LARGE).map { it.second },
            largeCount = large.size,
            largeSize = large.sumOf { it.first },
            recent = recent.sortedByDescending { it.first }.map { it.second },
            downloads = downloadFiles,
            downloadsSize = downloadFiles.sumOf { it.length() }
        )
    }

    suspend fun filesOf(category: Category): List<File> = withContext(Dispatchers.IO) {
        walk(root)
            .filter { it.isFile && !it.name.startsWith(".") && FileTypes.categoryOf(it) == category }
            .map { it to it.lastModified() }
            .sortedByDescending { it.second }
            .take(MAX_CATEGORY_FILES)
            .map { it.first }
            .toList()
    }

    suspend fun search(query: String, base: File = root): List<File> = withContext(Dispatchers.IO) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return@withContext emptyList<File>()
        walk(base)
            .filter { it != base && it.name.lowercase().contains(q) }
            .take(MAX_SEARCH_RESULTS)
            .toList()
    }

    fun delete(files: List<File>): Int = files.count { it.deleteRecursively() }

    fun rename(file: File, newName: String): Boolean {
        val name = newName.trim()
        if (name.isEmpty() || name.contains('/')) return false
        val target = File(file.parentFile, name)
        return !target.exists() && file.renameTo(target)
    }

    fun createFolder(parent: File, name: String): Boolean {
        val clean = name.trim()
        if (clean.isEmpty() || clean.contains('/')) return false
        val target = File(parent, clean)
        return !target.exists() && target.mkdirs()
    }

    /** Копирование или перемещение. Возвращает число успешно обработанных элементов. */
    fun paste(files: List<File>, targetDir: File, move: Boolean): Int {
        var done = 0
        for (src in files) {
            if (!src.exists()) continue
            if (move && src.parentFile == targetDir) continue
            if (src.isDirectory) {
                val into = targetDir.canonicalPath + File.separator
                if (into.startsWith(src.canonicalPath + File.separator)) continue
            }
            val dst = uniqueTarget(targetDir, src.name)
            val ok = try {
                if (move) {
                    src.renameTo(dst) || (src.copyRecursively(dst, false) && src.deleteRecursively())
                } else {
                    src.copyRecursively(dst, false)
                }
            } catch (e: Exception) {
                false
            }
            if (ok) done++
        }
        return done
    }

    private fun uniqueTarget(dir: File, name: String): File {
        var target = File(dir, name)
        if (!target.exists()) return target
        val base = target.nameWithoutExtension
        val ext = target.extension
        var i = 1
        while (target.exists()) {
            target = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext")
            i++
        }
        return target
    }

    companion object {
        const val LARGE_MIN = 10L * 1024 * 1024
        const val RECENT_COUNT = 10
        const val MAX_LARGE = 500
        const val MAX_CATEGORY_FILES = 2000
        const val MAX_SEARCH_RESULTS = 300
    }
}
