package com.filehub.app.ui

import android.os.Environment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.formatSize
import com.filehub.app.util.Toolchain
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AppRoot(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var toolsInfo by remember { mutableStateOf(false) }

    LaunchedEffect(vm.drawerRequest) {
        if (vm.drawerRequest > 0) drawerState.open()
    }

    fun close(action: () -> Unit) {
        scope.launch { drawerState.close() }
        action()
    }

    val root = vm.repo.root
    val priority = listOf("Download", "DCIM", "Documents", "Pictures", "Music", "Movies", "Android")
    val folders = (root.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") } ?: emptyList())
        .sortedWith(compareBy({ priority.indexOf(it.name).let { i -> if (i < 0) 99 else i } }, { it.name.lowercase() }))
        .map { it.name to it }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = false,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "Android XCODE",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(start = 28.dp, top = 24.dp, bottom = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Главная") },
                        icon = { Icon(Icons.Default.Home, null) },
                        selected = false,
                        onClick = { close { vm.goHome() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Внутренняя память") },
                        icon = { Icon(Icons.Default.Storage, null) },
                        selected = false,
                        onClick = { close { vm.openFolder(root) } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    for ((name, dir) in folders) {
                        NavigationDrawerItem(
                            label = { Text(name) },
                            icon = { Icon(Icons.Default.Folder, null) },
                            selected = false,
                            onClick = { close { vm.openFolder(dir) } },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    NavigationDrawerItem(
                        label = { Text("Приложения") },
                        icon = { Icon(Icons.Default.Apps, null) },
                        selected = false,
                        onClick = { close { vm.navigate(Screen.Apps) } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Поиск") },
                        icon = { Icon(Icons.Default.Search, null) },
                        selected = false,
                        onClick = { close { vm.navigate(Screen.Search) } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Очистка") },
                        icon = { Icon(Icons.Default.CleaningServices, null) },
                        selected = false,
                        onClick = { close { vm.navigate(Screen.Clean) } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Инструменты сборки") },
                        icon = { Icon(Icons.Default.Build, null) },
                        selected = false,
                        onClick = { close { toolsInfo = true } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        label = { Text("Настройки") },
                        icon = { Icon(Icons.Default.Settings, null) },
                        selected = false,
                        onClick = { close { vm.navigate(Screen.Settings) } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    ) {
        val screen = vm.current
        key(screen) {
            when (screen) {
                Screen.Home -> HomeScreen(vm)
                Screen.Clean -> CleanScreen(vm)
                Screen.Settings -> SettingsScreen(vm)
                Screen.Search -> SearchScreen(vm)
                Screen.Large -> FilesScreen(
                    vm = vm,
                    title = "Крупные файлы",
                    subtitle = vm.scan?.let { "от 10 МБ · всего ${formatSize(it.largeSize)}" },
                    loader = { vm.scan?.large.orEmpty().filter { it.exists() } }
                )
                is Screen.Browser -> FilesScreen(
                    vm = vm,
                    title = if (screen.dir == vm.repo.root) "Внутренняя память" else screen.dir.name,
                    subtitle = screen.dir.path,
                    dir = screen.dir,
                    loader = { vm.repo.list(screen.dir, vm.showHidden, vm.sort) }
                )
                is Screen.Viewer -> ViewerScreen(vm, screen.file, screen.asText, screen.readOnly)
                is Screen.Archive -> ArchiveScreen(vm, screen.zip, screen.prefix)
                Screen.Apps -> AppsScreen(vm)
                is Screen.CategoryList -> FilesScreen(
                    vm = vm,
                    title = screen.category.label,
                    loader = { vm.repo.filesOf(screen.category) }
                )
            }
        }
    }

    if (toolsInfo) {
        val installed = Toolchain.root(ctx)
        AlertDialog(
            onDismissRequest = { toolsInfo = false },
            title = { Text("Инструменты сборки") },
            text = {
                Text(
                    if (installed != null) "Установлены. Нажмите ▶ в редакторе — проект из папки открытого файла будет собран в APK."
                    else "Не установлены. Найдите файл .tar.gz с инструментами (с файлом build.sh внутри), " +
                        "нажмите ⋮ рядом с ним → «Установить как инструменты сборки»."
                )
            },
            confirmButton = { TextButton(onClick = { toolsInfo = false }) { Text("OK") } }
        )
    }
}
