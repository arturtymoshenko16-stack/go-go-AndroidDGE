package com.filehub.app.util

import android.content.Context
import android.system.Os
import java.io.File
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

/**
 * Набор инструментов сборки (tar.gz с aarch64-программами).
 * Соглашение: в архиве есть build.sh, вызывается как
 *   sh build.sh <папка_проекта> <выходной_unsigned.apk>
 * Переменные окружения: TOOLCHAIN (корень набора), HOME, TMPDIR.
 */
object Toolchain {

    fun dir(ctx: Context) = File(ctx.filesDir, "toolchain")

    fun root(ctx: Context): File? {
        val d = dir(ctx)
        if (File(d, "build.sh").isFile) return d
        return d.listFiles()?.firstOrNull { it.isDirectory && File(it, "build.sh").isFile }
    }

    fun isTarGz(f: File): Boolean {
        val n = f.name.lowercase()
        return n.endsWith(".tar.gz") || n.endsWith(".tgz")
    }

    private fun readFully(ins: InputStream, buf: ByteArray, len: Int): Boolean {
        var off = 0
        while (off < len) {
            val n = ins.read(buf, off, len - off)
            if (n < 0) return false
            off += n
        }
        return true
    }

    private fun str(b: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && b[end].toInt() != 0) end++
        return String(b, off, end - off, Charsets.UTF_8)
    }

    private fun octal(b: ByteArray, off: Int, len: Int): Long =
        str(b, off, len).trim().ifEmpty { "0" }.toLong(8)

    /** Распаковка tar.gz с правами и симлинками. Возвращает число файлов. */
    fun install(ctx: Context, archive: File): Int {
        val dest = dir(ctx)
        dest.deleteRecursively()
        dest.mkdirs()
        val destPath = dest.canonicalPath + File.separator
        var count = 0
        var longName: String? = null
        val hdr = ByteArray(512)
        GZIPInputStream(archive.inputStream().buffered(1 shl 16)).use { ins ->
            while (true) {
                if (!readFully(ins, hdr, 512)) break
                if (hdr.all { it.toInt() == 0 }) break
                var name = str(hdr, 0, 100)
                val prefix = str(hdr, 345, 155)
                if (prefix.isNotEmpty() && str(hdr, 257, 5) == "ustar") name = "$prefix/$name"
                val size = octal(hdr, 124, 12)
                val type = hdr[156].toInt().toChar()
                val mode = octal(hdr, 100, 8).toInt()
                val link = str(hdr, 157, 100)
                val padded = (size + 511) / 512 * 512

                if (type == 'L' || type == 'x' || type == 'g') {
                    val data = ByteArray(size.toInt())
                    readFully(ins, data, data.size)
                    ins.skip(padded - size)
                    if (type == 'L') longName = str(data, 0, data.size)
                    if (type == 'x') {
                        String(data, Charsets.UTF_8).lines().forEach {
                            val i = it.indexOf(" path=")
                            if (i >= 0) longName = it.substring(i + 6)
                        }
                    }
                    continue
                }
                if (longName != null) { name = longName!!; longName = null }
                val target = File(dest, name)
                if (!target.canonicalPath.plus(if (type == '5') File.separator else "").startsWith(destPath)) {
                    ins.skip(padded); continue
                }
                when (type) {
                    '5' -> target.mkdirs()
                    '2' -> {
                        target.parentFile?.mkdirs()
                        runCatching { target.delete(); Os.symlink(link, target.path) }
                        ins.skip(padded)
                    }
                    '1' -> {
                        target.parentFile?.mkdirs()
                        val src = File(dest, link)
                        if (src.isFile) src.copyTo(target, overwrite = true)
                        if (mode and 0x49 != 0) target.setExecutable(true, false)
                    }
                    '0', '\u0000' -> {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { o ->
                            var left = size
                            val buf = ByteArray(65536)
                            while (left > 0) {
                                val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                                if (n < 0) break
                                o.write(buf, 0, n); left -= n
                            }
                        }
                        ins.skip(padded - size)
                        target.setReadable(true, false)
                        if (mode and 0x49 != 0) target.setExecutable(true, false)
                        count++
                    }
                    else -> ins.skip(padded)
                }
            }
        }
        return count
    }

    /** Запускает build.sh. Возвращает (код выхода, последние строки лога). */
    fun run(ctx: Context, project: File, out: File): Pair<Int, String> {
        val root = root(ctx) ?: return -1 to "Инструменты не установлены"
        File(root, "build.sh").setExecutable(true, false)
        val pb = ProcessBuilder("/system/bin/sh", File(root, "build.sh").path, project.path, out.path)
            .directory(project)
            .redirectErrorStream(true)
        pb.environment().apply {
            put("TOOLCHAIN", root.path)
            put("HOME", ctx.filesDir.path)
            put("TMPDIR", ctx.cacheDir.path)
            put("PATH", File(root, "bin").path + ":" + (get("PATH") ?: "/system/bin"))
        }
        val p = pb.start()
        val tail = ArrayDeque<String>()
        val reader = Thread {
            p.inputStream.bufferedReader().forEachLine {
                tail.addLast(it); if (tail.size > 40) tail.removeFirst()
            }
        }
        reader.start()
        if (!p.waitFor(20, TimeUnit.MINUTES)) { p.destroyForcibly(); return -2 to "Таймаут сборки" }
        reader.join(2000)
        return p.exitValue() to tail.joinToString("\n")
    }
}
