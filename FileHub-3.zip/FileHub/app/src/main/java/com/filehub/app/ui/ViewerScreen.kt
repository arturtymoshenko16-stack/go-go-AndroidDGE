@file:OptIn(ExperimentalMaterial3Api::class)

package com.filehub.app.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.selection.DisableSelection
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.filehub.app.MainViewModel
import com.filehub.app.data.FileTypes
import com.filehub.app.data.formatSize
import com.filehub.app.util.FileActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

private const val MAX_BYTES = 1_000_000

/** Читает до 1 МБ. Кодировка: UTF-8, а если не подходит — windows-1251 (частый случай для русских .txt). */
private fun readTextFile(file: File): Pair<String, Boolean> {
    val buf = ByteArray(MAX_BYTES + 1)
    var total = 0
    file.inputStream().use { input ->
        while (total < buf.size) {
            val n = input.read(buf, total, buf.size - total)
            if (n <= 0) break
            total += n
        }
    }
    val truncated = total > MAX_BYTES
    val len = if (truncated) MAX_BYTES else total
    return decodeBytes(buf, len).removePrefix("﻿") to truncated
}

private fun decodeBytes(bytes: ByteArray, len: Int): String {
    // Обрезка могла разрезать многобайтный символ, поэтому пробуем отступить на пару байт.
    for (cut in 0..3) {
        if (len - cut < 0) break
        try {
            val decoder = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            return decoder.decode(ByteBuffer.wrap(bytes, 0, len - cut)).toString()
        } catch (e: CharacterCodingException) {
            // пробуем дальше
        }
    }
    return String(bytes, 0, len, Charset.forName("windows-1251"))
}

private fun decodeSampled(file: File, maxSide: Int): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) {
        sample *= 2
    }
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeFile(file.path, options)?.asImageBitmap()
}

@Composable
fun ViewerScreen(vm: MainViewModel, file: File, asText: Boolean) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val isImage = !asText && FileTypes.isImage(file)

    var text by remember { mutableStateOf<String?>(null) }
    var truncated by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var fontSize by remember { mutableIntStateOf(14) }
    var showMenu by remember { mutableStateOf(false) }

    LaunchedEffect(file) {
        if (!isImage) {
            val result = withContext(Dispatchers.IO) { runCatching { readTextFile(file) } }
            result
                .onSuccess {
                    text = it.first
                    truncated = it.second
                }
                .onFailure { failed = true }
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            SimpleTopBar(
                title = file.name,
                subtitle = formatSize(file.length()),
                onBack = { vm.back() },
                actions = {
                    if (!isImage) {
                        IconButton(onClick = { if (fontSize > 8) fontSize -= 2 }) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "Меньше")
                        }
                        IconButton(onClick = { if (fontSize < 32) fontSize += 2 }) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "Больше")
                        }
                    }
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Меню")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            val content = text
            when {
                isImage -> ImageContent(file)
                failed -> Text(
                    "Не удалось прочитать файл",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center)
                )
                content == null -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
                else -> TextContent(content, truncated, fontSize)
            }
        }
    }

    if (showMenu) {
        val currentText = text
        val actions = buildList<SheetAction> {
            if (!isImage && currentText != null) {
                add(SheetAction(Icons.Default.ContentCopy, "Копировать весь текст") {
                    clipboard.setText(AnnotatedString(currentText))
                    FileActions.toast(ctx, "Скопировано")
                })
            }
            add(SheetAction(Icons.Default.Share, "Поделиться") {
                FileActions.share(ctx, listOf(file))
            })
            add(SheetAction(Icons.Default.Apps, "Открыть в другом приложении") {
                FileActions.open(ctx, file)
            })
        }
        ActionSheet(
            title = file.name,
            subtitle = formatSize(file.length()),
            headerIcon = iconFor(file),
            headerTint = tintFor(file),
            actions = actions,
            onDismiss = { showMenu = false }
        )
    }
}

@Composable
private fun TextContent(text: String, truncated: Boolean, fontSize: Int) {
    val cs = MaterialTheme.colorScheme
    val lines = remember(text) { text.split('\n') }

    Column(modifier = Modifier.fillMaxSize()) {
        if (truncated) {
            Text(
                "Показан только первый мегабайт файла",
                style = MaterialTheme.typography.bodySmall,
                color = cs.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(cs.surface)
                    .padding(10.dp)
            )
        }
        SelectionContainer(modifier = Modifier.weight(1f)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                itemsIndexed(lines) { index, line ->
                    Row {
                        DisableSelection {
                            Text(
                                "${index + 1}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = (fontSize - 3).sp,
                                color = cs.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.width(44.dp)
                            )
                        }
                        Text(
                            line.trimEnd('\r').ifEmpty { " " },
                            fontFamily = FontFamily.Monospace,
                            fontSize = fontSize.sp,
                            lineHeight = (fontSize * 1.45f).sp,
                            color = cs.onBackground,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageContent(file: File) {
    val cs = MaterialTheme.colorScheme
    var bitmap by remember(file) { mutableStateOf<ImageBitmap?>(null) }
    var failed by remember(file) { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    LaunchedEffect(file) {
        val decoded = withContext(Dispatchers.IO) { decodeSampled(file, 2048) }
        if (decoded == null) failed = true else bitmap = decoded
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    scale = 1f
                    offset = Offset.Zero
                })
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (scale * zoom).coerceIn(1f, 6f)
                    scale = newScale
                    offset = if (newScale <= 1f) Offset.Zero else offset + pan
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val image = bitmap
        when {
            failed -> Text("Не удалось открыть изображение", color = cs.onSurfaceVariant)
            image == null -> CircularProgressIndicator()
            else -> Image(
                bitmap = image,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            )
        }
    }
}
