package com.filehub.app.util

import android.content.Context
import com.filehub.app.data.ZipTools
import java.io.File

sealed interface ApkResult {
    data class Ok(val apk: File) : ApkResult
    data class Fail(val message: String) : ApkResult
}

object ApkBuild {

    private fun isBinaryManifest(f: File): Boolean = runCatching {
        f.inputStream().use { val b = ByteArray(4); it.read(b) == 4 && b[0] == 3.toByte() && b[1] == 0.toByte() }
    }.getOrDefault(false)

    /** Папка с готовым содержимым APK (AndroidManifest.xml, classes.dex, resources.arsc…) → подписанный .apk рядом. */
    fun build(ctx: Context, folder: File): ApkResult {
        val manifest = File(folder, "AndroidManifest.xml")
        if (!manifest.isFile) {
            val src = File(folder, "build.gradle").exists() || File(folder, "build.gradle.kts").exists() ||
                File(folder, "src").isDirectory
            return ApkResult.Fail(
                if (src) "Это папка с исходниками. Компиляция Java/Kotlin здесь недоступна — " +
                    "соберите проект через GitHub Actions или Android Studio, потом упакуйте результат."
                else "В папке нет AndroidManifest.xml"
            )
        }
        if (!isBinaryManifest(manifest)) {
            return ApkResult.Fail(
                "AndroidManifest.xml в текстовом виде (исходники). Нужен скомпилированный (бинарный) манифест, как в распакованном APK."
            )
        }
        return try {
            val parent = folder.parentFile ?: return ApkResult.Fail("Нет родительской папки")
            val target = uniqueFile(parent, folder.name, "apk")
            val tmp = File(ctx.cacheDir, "pack_${System.currentTimeMillis()}.apk")
            ApkPack.pack(folder, tmp)
            try {
                ApkSign.sign(ctx, tmp, target)
            } finally {
                tmp.delete()
            }
            ApkResult.Ok(target)
        } catch (e: Throwable) {
            ApkResult.Fail("Ошибка сборки: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Корень Gradle-проекта: поднимаемся вверх до папки с settings.gradle(.kts). */
    fun findGradleRoot(start: File): File? {
        var d: File? = start
        var depth = 0
        while (d != null && depth < 8) {
            if (File(d, "settings.gradle.kts").isFile || File(d, "settings.gradle").isFile) return d
            d = d.parentFile
            depth++
        }
        return null
    }

    /** Gradle-проект: gradle assembleDebug через набор инструментов. */
    fun buildGradle(ctx: Context, root: File): ApkResult {
        return try {
            val parent = root.parentFile ?: return ApkResult.Fail("Нет родительской папки")
            val tmp = File(ctx.cacheDir, "gradle_${System.currentTimeMillis()}.apk")
            val (code, log) = Toolchain.runScript(ctx, "build-gradle.sh", root, tmp)
            if (code != 0 || !tmp.isFile) {
                tmp.delete()
                return ApkResult.Fail("Gradle-сборка не удалась (код $code):\n$log")
            }
            val target = uniqueFile(parent, root.name + "-debug", "apk")
            tmp.copyTo(target)
            tmp.delete()
            ApkResult.Ok(target)
        } catch (e: Throwable) {
            ApkResult.Fail("Ошибка: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Готовый распакованный APK → упаковка; иначе исходники → набор инструментов. */
    fun auto(ctx: Context, folder: File): ApkResult {
        val m = File(folder, "AndroidManifest.xml")
        if (m.isFile && isBinaryManifest(m)) return build(ctx, folder)
        if (Toolchain.root(ctx) == null) {
            return ApkResult.Fail(
                "Не установлены инструменты сборки. Откройте меню ☰ → «Инструменты» " +
                    "или нажмите ⋮ у файла .tar.gz → «Установить как инструменты сборки»."
            )
        }
        findGradleRoot(folder)?.let { return buildGradle(ctx, it) }
        val hasJava = File(folder, "src").walkTopDown().any { it.isFile && it.extension == "java" }
        val hasNative = listOf(File(folder, "jni"), folder).any { d ->
            d.listFiles()?.any { it.isFile && (it.extension == "c" || it.extension == "cpp") } == true
        }
        return if (!hasJava && hasNative) buildNative(ctx, folder) else buildProject(ctx, folder)
    }

    /** Приложение целиком на C++ (NativeActivity): .so (NDK) + манифест (aapt2) → упаковка и подпись. */
    fun buildNative(ctx: Context, folder: File): ApkResult {
        val so = buildSo(ctx, folder)
        if (so is ApkResult.Fail) return so
        return try {
            val parent = folder.parentFile ?: return ApkResult.Fail("Нет родительской папки")
            val stage = File(ctx.cacheDir, "native_stage")
            val (code, log) = Toolchain.runScript(ctx, "build-native.sh", folder, stage)
            if (code != 0 || !File(stage, "AndroidManifest.xml").isFile) {
                return ApkResult.Fail("Не удалось собрать манифест (код $code):\n$log")
            }
            val libs = File(folder, "libs")
            libs.copyRecursively(File(stage, "lib"), overwrite = true)
            val tmp = File(ctx.cacheDir, "native_${System.currentTimeMillis()}.apk")
            ApkPack.pack(stage, tmp)
            val target = uniqueFile(parent, folder.name, "apk")
            try { ApkSign.sign(ctx, tmp, target) } finally { tmp.delete(); stage.deleteRecursively() }
            ApkResult.Ok(target)
        } catch (e: Throwable) {
            ApkResult.Fail("Ошибка: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Сборка нативных библиотек (.so) через NDK из набора инструментов:
     * sh build-so.sh <папка_проекта> <папка_libs>. Результат — папка <проект>/libs.
     */
    fun buildSo(ctx: Context, folder: File): ApkResult {
        if (Toolchain.root(ctx) == null) {
            return ApkResult.Fail("Сначала установите набор инструментов (Настройки → Инструменты сборки).")
        }
        return try {
            val out = File(folder, "libs")
            out.mkdirs()
            val (code, log) = Toolchain.runScript(ctx, "build-so.sh", folder, out)
            val count = out.walkTopDown().count { it.isFile && it.extension == "so" }
            if (code != 0 || count == 0) {
                ApkResult.Fail("Сборка .so не удалась (код $code, файлов .so: $count):\n$log")
            } else {
                ApkResult.Ok(out)
            }
        } catch (e: Throwable) {
            ApkResult.Fail("Ошибка: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Сборка проекта из исходников через установленный набор инструментов (tar.gz). */
    fun buildProject(ctx: Context, folder: File): ApkResult {
        if (Toolchain.root(ctx) == null) {
            return ApkResult.Fail("Сначала установите набор инструментов: меню ⋮ у файла .tar.gz → «Установить как инструменты сборки»")
        }
        findGradleRoot(folder)?.let { return buildGradle(ctx, it) }
        return try {
            val parent = folder.parentFile ?: return ApkResult.Fail("Нет родительской папки")
            val unsigned = File(ctx.cacheDir, "proj_${System.currentTimeMillis()}.apk")
            val (code, log) = Toolchain.run(ctx, folder, unsigned)
            if (code != 0 || !unsigned.isFile) {
                unsigned.delete()
                return ApkResult.Fail("Сборка не удалась (код $code):\n$log")
            }
            val target = uniqueFile(parent, folder.name, "apk")
            try { ApkSign.sign(ctx, unsigned, target) } finally { unsigned.delete() }
            ApkResult.Ok(target)
        } catch (e: Throwable) {
            ApkResult.Fail("Ошибка: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun uniqueFile(dir: File, base: String, ext: String): File {
        var f = File(dir, "$base.$ext")
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i).$ext"); i++ }
        return f
    }
}
