package com.filehub.app.util

import android.content.Context
import com.filehub.app.data.ZipTools
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

sealed interface BuildStep {
    data class Replace(val path: String, val old: String, val new: String) : BuildStep
    data class Delete(val path: String) : BuildStep
    data class Copy(val from: String, val to: String) : BuildStep
}

class BuildConfig {
    var name: String? = null
    var from: String = "."
    var install: Boolean = false
    val steps = ArrayList<BuildStep>()
}

class BuildResult(val apk: File?, val install: Boolean)

/**
 * Встроенный «движок сборки»: читает файл xcode.build из ZIP, применяет шаги (замена текста, удаление, копирование),
 * упаковывает папку в APK, подписывает и сохраняет в FileHub/APK. Компилятора Java/Kotlin здесь нет:
 * в архиве должны лежать готовые AndroidManifest.xml (бинарный), classes.dex и ресурсы.
 */
object BuildRunner {
    const val BUILD_FILE = "xcode.build"

    val SAMPLE = """
# xcode.build — инструкция сборки APK
# Положите этот файл в ZIP рядом с AndroidManifest.xml (или выше, указав from:)

name: MyApp

# папка внутри архива, из которой собирается APK (по умолчанию — там, где лежит xcode.build)
from: .

# замена текста: файл | что искать | на что менять
replace: assets/scripts/main.lua | speed = 1 | speed = 2

# удалить файл или папку
delete: assets/ads.png

# скопировать файл или папку
copy: assets/a.lua -> assets/b.lua

# сразу открыть установщик после сборки
install: yes
""".trimStart()

    fun canBuild(zip: File): Boolean {
        return ZipTools.findEntry(zip, BUILD_FILE) != null ||
            ZipTools.findEntry(zip, "AndroidManifest.xml") == "AndroidManifest.xml"
    }

    fun parse(text: String): BuildConfig {
        val cfg = BuildConfig()
        for (raw in text.lines()) {
            val line = raw.trim().removePrefix("﻿")
            if (line.isEmpty() || line.startsWith("#")) continue
            val idx = line.indexOf(':')
            if (idx <= 0) throw IllegalArgumentException("Не понял строку: $line")
            val key = line.substring(0, idx).trim().lowercase()
            val value = line.substring(idx + 1).trim()
            when (key) {
                "name" -> cfg.name = value
                "from" -> cfg.from = value.trim('/').ifEmpty { "." }
                "install" -> cfg.install = value.lowercase() in setOf("yes", "true", "да", "1")
                "output" -> if (value.lowercase() != "apk") {
                    throw IllegalArgumentException("output: поддерживается только apk")
                }
                "replace" -> {
                    val p = value.split("|").map { it.trim() }
                    if (p.size < 3 || p[0].isEmpty() || p[1].isEmpty()) {
                        throw IllegalArgumentException("replace: нужен формат  файл | что | на что  ($line)")
                    }
                    cfg.steps.add(BuildStep.Replace(p[0], p[1], p.drop(2).joinToString("|")))
                }
                "delete" -> {
                    if (value.isEmpty()) throw IllegalArgumentException("delete: не указан путь")
                    cfg.steps.add(BuildStep.Delete(value))
                }
                "copy" -> {
                    val p = value.split("->").map { it.trim() }
                    if (p.size != 2 || p[0].isEmpty() || p[1].isEmpty()) {
                        throw IllegalArgumentException("copy: нужен формат  откуда -> куда  ($line)")
                    }
                    cfg.steps.add(BuildStep.Copy(p[0], p[1]))
                }
                else -> throw IllegalArgumentException("Неизвестная команда: $key")
            }
        }
        return cfg
    }

    private fun inside(root: File, rel: String): File {
        val f = File(root, rel.trimStart('/'))
        val rc = root.canonicalPath
        val fc = f.canonicalPath
        if (fc != rc && !fc.startsWith(rc + File.separator)) {
            throw IllegalArgumentException("Путь выходит за пределы проекта: $rel")
        }
        return f
    }

    private fun decode(bytes: ByteArray): Pair<String, Charset> {
        return try {
            val d = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            d.decode(ByteBuffer.wrap(bytes)).toString() to Charsets.UTF_8
        } catch (e: CharacterCodingException) {
            val cp = Charset.forName("windows-1251")
            String(bytes, cp) to cp
        }
    }

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "app" }

    /** Выполняет сборку и пишет ход работы в log. При ошибке бросает исключение с понятным текстом. */
    fun run(ctx: Context, zip: File, log: (String) -> Unit): BuildResult {
        log("▶ Android XCODE · сборка APK")
        log("Архив: ${zip.name}")

        val buildEntry = ZipTools.findEntry(zip, BUILD_FILE)
        val base = buildEntry?.removeSuffix(BUILD_FILE) ?: ""

        val workRoot = File(ctx.cacheDir, "xcode_build")
        workRoot.deleteRecursively()
        val dest = File(workRoot, "src")
        dest.mkdirs()

        log("Распаковка…")
        val count = ZipTools.extract(zip, base, dest)
        log("  ✓ файлов: $count")
        val srcRoot = if (base.isEmpty()) dest else File(dest, base.trimEnd('/').substringAfterLast('/'))

        val cfg: BuildConfig
        if (buildEntry != null) {
            log("Читаю $BUILD_FILE")
            cfg = parse(File(srcRoot, BUILD_FILE).readText(Charsets.UTF_8))
            log("  ✓ шагов: ${cfg.steps.size}")
        } else {
            log("Файла $BUILD_FILE нет — собираю как есть")
            cfg = BuildConfig()
        }

        for (step in cfg.steps) {
            when (step) {
                is BuildStep.Replace -> {
                    val f = inside(srcRoot, step.path)
                    if (!f.isFile) throw IllegalArgumentException("replace: файл не найден: ${step.path}")
                    val (text, charset) = decode(f.readBytes())
                    val found = text.split(step.old).size - 1
                    if (found == 0) {
                        log("  ⚠ replace: в ${step.path} не найдено «${step.old}»")
                    } else {
                        f.writeBytes(text.replace(step.old, step.new).toByteArray(charset))
                        log("  ✓ replace: ${step.path} — замен: $found")
                    }
                }
                is BuildStep.Delete -> {
                    val f = inside(srcRoot, step.path)
                    if (f.exists()) {
                        f.deleteRecursively()
                        log("  ✓ delete: ${step.path}")
                    } else {
                        log("  ⚠ delete: не найдено ${step.path}")
                    }
                }
                is BuildStep.Copy -> {
                    val from = inside(srcRoot, step.from)
                    val to = inside(srcRoot, step.to)
                    if (!from.exists()) throw IllegalArgumentException("copy: не найдено ${step.from}")
                    to.parentFile?.mkdirs()
                    if (from.isDirectory) from.copyRecursively(to, true) else from.copyTo(to, true)
                    log("  ✓ copy: ${step.from} → ${step.to}")
                }
            }
        }

        val apkRoot = inside(srcRoot, cfg.from)
        val manifest = File(apkRoot, "AndroidManifest.xml")
        if (!manifest.isFile) {
            throw IllegalStateException(
                "В папке сборки нет AndroidManifest.xml. Положите готовые файлы APK (манифест, classes.dex, ресурсы) " +
                    "или укажите папку командой from:"
            )
        }
        val head = ByteArray(4)
        manifest.inputStream().use { it.read(head) }
        val binary = head[0] == 3.toByte() && head[1] == 0.toByte() && head[2] == 8.toByte() && head[3] == 0.toByte()
        if (!binary) {
            throw IllegalStateException(
                "AndroidManifest.xml в текстовом виде (так бывает после apktool). " +
                    "Здесь нет компилятора ресурсов — нужен бинарный манифест из настоящего APK."
            )
        }
        if (apkRoot.walkTopDown().none { it.isFile && it.name.endsWith(".dex") }) {
            log("  ⚠ нет файлов .dex — приложение не сможет запуститься")
        }

        log("Упаковка APK…")
        val unsigned = File(workRoot, "unsigned.apk")
        ApkPacker.pack(apkRoot, unsigned, log)

        log("Подпись…")
        val outDir = AppTools.backupDir()
        val out = File(outDir, safeName(cfg.name ?: zip.nameWithoutExtension) + "_xcode.apk")
        ApkSign.sign(ctx, unsigned, out)
        log("  ✓ подписано (v1 + v2 + v3)")

        workRoot.deleteRecursively()
        log("")
        log("✓ Готово: ${out.name}")
        log("  Папка: ${out.parent}")
        log("  Размер: ${com.filehub.app.data.formatSize(out.length())}")
        return BuildResult(out, cfg.install)
    }
}
