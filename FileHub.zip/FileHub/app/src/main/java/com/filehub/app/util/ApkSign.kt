package com.filehub.app.util

import android.content.Context
import com.android.apksig.ApkSigner
import java.io.File
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate

/**
 * Подписывает APK ключом из assets/xcode.p12 (схемы подписи v1, v2 и v3).
 * Ключ общий для всех сборок этого приложения: он нужен, чтобы Android согласился установить APK,
 * а не для защиты авторства.
 */
object ApkSign {
    fun sign(ctx: Context, unsigned: File, out: File) {
        val pass = "android".toCharArray()
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("xcode.p12").use { ks.load(it, pass) }
        val key = ks.getKey("xcode", pass) as PrivateKey
        val cert = ks.getCertificate("xcode") as X509Certificate

        val signer = ApkSigner.SignerConfig.Builder("xcode", key, listOf(cert)).build()

        out.parentFile?.mkdirs()
        if (out.exists()) out.delete()

        ApkSigner.Builder(listOf(signer))
            .setInputApk(unsigned)
            .setOutputApk(out)
            .setMinSdkVersion(26)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }
}
