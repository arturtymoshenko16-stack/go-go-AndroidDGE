package com.filehub.app.util

import java.io.File
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream

/**
 * Упаковывает папку в неподписанный APK (обычный ZIP) и выравнивает несжатые записи, как это делает zipalign:
 * resources.arsc — по 4 байта, нативные библиотеки .so — по 4096 байт. Это нужно, чтобы APK ставился на Android 11+.
 */
object ApkPacker {

    private val STORE_EXT = setOf("png", "jpg", "jpeg", "gif", "webp", "ogg", "mp3", "mp4", "zip", "jar")

    // 2009-01-01 00:00 в формате DOS — фиксированная дата, чтобы сборка была воспроизводимой
    private const val DOS_DATE = ((2009 - 1980) shl 9) or (1 shl 5) or 1
    private const val DOS_TIME = 0

    private class Counter(private val o: OutputStream) : OutputStream() {
        var count = 0L
        override fun write(b: Int) {
            o.write(b)
            count++
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            o.write(b, off, len)
            count += len
        }

        override fun flush() = o.flush()
        override fun close() = o.close()
    }

    private class CEntry(
        val name: ByteArray,
        val crc: Long,
        val method: Int,
        val comp: Long,
        val size: Long,
        val offset: Long
    )

    private fun OutputStream.le16(v: Int) {
        write(v and 0xFF)
        write((v shr 8) and 0xFF)
    }

    private fun OutputStream.le32(v: Long) {
        for (i in 0..3) write(((v shr (8 * i)) and 0xFF).toInt())
    }

    private fun isSignature(n: String): Boolean {
        if (!n.startsWith("META-INF/")) return false
        val rest = n.removePrefix("META-INF/")
        if (rest.contains('/')) return false
        val u = rest.uppercase()
        return u == "MANIFEST.MF" || u.endsWith(".SF") || u.endsWith(".RSA") ||
            u.endsWith(".DSA") || u.endsWith(".EC")
    }

    fun pack(root: File, out: File, log: (String) -> Unit) {
        val files = root.walkTopDown()
            .filter { it.isFile }
            .map { it to it.relativeTo(root).path.replace(File.separatorChar, '/') }
            .filter { !isSignature(it.second) }
            .sortedWith(
                compareBy<Pair<File, String>>({ it.second != "AndroidManifest.xml" }, { it.second })
            )
            .toList()

        if (files.size > 65000) throw IllegalStateException("Слишком много файлов: ${files.size}")

        out.parentFile?.mkdirs()
        val tmp = File(out.parentFile, "entry.tmp")
        val entries = ArrayList<CEntry>()
        val buf = ByteArray(64 * 1024)

        Counter(out.outputStream().buffered()).use { os ->
            for ((file, name) in files) {
                val nameBytes = name.toByteArray(Charsets.UTF_8)
                val ext = name.substringAfterLast('.', "").lowercase()
                val stored = name == "resources.arsc" || ext == "so" || ext in STORE_EXT
                val align = if (ext == "so") 4096 else 4

                val crc = CRC32()
                var size = 0L
                val method: Int
                val comp: Long

                if (stored) {
                    file.inputStream().use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            crc.update(buf, 0, n)
                            size += n
                        }
                    }
                    method = 0
                    comp = size
                } else {
                    val deflater = Deflater(6, true)
                    DeflaterOutputStream(tmp.outputStream().buffered(), deflater).use { dos ->
                        file.inputStream().use { ins ->
                            while (true) {
                                val n = ins.read(buf)
                                if (n <= 0) break
                                crc.update(buf, 0, n)
                                size += n
                                dos.write(buf, 0, n)
                            }
                        }
                    }
                    deflater.end()
                    method = 8
                    comp = tmp.length()
                }

                val offset = os.count
                val pad = if (stored) {
                    ((align - ((offset + 30 + nameBytes.size) % align)) % align).toInt()
                } else {
                    0
                }

                os.le32(0x04034b50L)
                os.le16(if (method == 0) 10 else 20)
                os.le16(0x0800)
                os.le16(method)
                os.le16(DOS_TIME)
                os.le16(DOS_DATE)
                os.le32(crc.value)
                os.le32(comp)
                os.le32(size)
                os.le16(nameBytes.size)
                os.le16(pad)
                os.write(nameBytes)
                if (pad > 0) os.write(ByteArray(pad))

                if (stored) {
                    file.inputStream().use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            os.write(buf, 0, n)
                        }
                    }
                } else {
                    tmp.inputStream().use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            os.write(buf, 0, n)
                        }
                    }
                }

                entries.add(CEntry(nameBytes, crc.value, method, comp, size, offset))
            }

            val cdStart = os.count
            for (e in entries) {
                os.le32(0x02014b50L)
                os.le16(20)
                os.le16(if (e.method == 0) 10 else 20)
                os.le16(0x0800)
                os.le16(e.method)
                os.le16(DOS_TIME)
                os.le16(DOS_DATE)
                os.le32(e.crc)
                os.le32(e.comp)
                os.le32(e.size)
                os.le16(e.name.size)
                os.le16(0)
                os.le16(0)
                os.le16(0)
                os.le16(0)
                os.le32(0)
                os.le32(e.offset)
                os.write(e.name)
            }
            val cdSize = os.count - cdStart

            os.le32(0x06054b50L)
            os.le16(0)
            os.le16(0)
            os.le16(entries.size)
            os.le16(entries.size)
            os.le32(cdSize)
            os.le32(cdStart)
            os.le16(0)
        }
        tmp.delete()
        log("  ✓ упаковано файлов: ${entries.size}")
    }
}
