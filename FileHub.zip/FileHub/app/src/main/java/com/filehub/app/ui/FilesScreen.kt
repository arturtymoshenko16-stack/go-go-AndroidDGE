@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.filehub.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.SortMode
import com.filehub.app.data.formatSize
import com.filehub.app.util.FileActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Универсальный список файлов: обзор папки (dir != null), категория, крупные файлы.
 * Долгое нажатие включает режим выделения.
 */
@Composable
fun FilesScreen(
    vm: MainViewModel,
    title: String,
    subtitle: String? = null,
    dir: File? = null,
    loader: suspend () -> List<File>
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    var files by remember { mutableStateOf<List<File>?>(null) }
    val selected = remember { mutableStateListOf<File>() }
    val selecting = selected.isNotEmpty()

    var showDelete by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showNewFolder by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var selMenuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(vm.tick, vm.sort, vm.showHidden, vm.scan) {
        files = withContext(Dispatchers.IO) { loader() }
        selected.removeAll { !it.exists() }
    }

    BackHandler(enabled = selecting) { selected.clear() }

    fun toggle(f: File) {
        if (selected.contains(f)) selected.remove(f) else selected.add(f)
    }

    val selectedSize = remember(selected.size) {
        selected.sumOf { if (it.isFile) it.length() else 0L }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            if (selecting) {
                SimpleTopBar(
                    title = "Выбрано: ${selected.size}",
                    subtitle = formatSize(selectedSize),
                    onBack = { selected.clear() },
                    navIcon = Icons.Default.Close,
                    actions = {
                        IconButton(onClick = { FileActions.share(ctx, selected.toList()) }) {
                            Icon(Icons.Default.Share, contentDescription = "Отправить")
                        }
                        IconButton(onClick = { showDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Удалить")
                        }
                        Box {
                            IconButton(onClick = { selMenuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "Ещё")
                            }
                            DropdownMenu(
                                expanded = selMenuOpen,
                                onDismissRequest = { selMenuOpen = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Выбрать всё") },
                                    onClick = {
                                        selMenuOpen = false
                                        val all = files.orEmpty()
                                        selected.clear()
                                        selected.addAll(all)
                                    }
                                )
                                if (dir != null) {
                                    DropdownMenuItem(
                                        text = { Text("Копировать") },
                                        onClick = {
                                            selMenuOpen = false
                                            vm.putToClipboard(selected.toList(), false)
                                            selected.clear()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Переместить") },
                                        onClick = {
                                            selMenuOpen = false
                                            vm.putToClipboard(selected.toList(), true)
                                            selected.clear()
                                        }
                                    )
                                    if (selected.size == 1) {
                                        DropdownMenuItem(
                                            text = { Text("Переименовать") },
                                            onClick = {
                                                selMenuOpen = false
                                                showRename = true
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                )
            } else {
                SimpleTopBar(
                    title = title,
                    subtitle = subtitle,
                    onBack = { vm.back() },
                    actions = {
                        if (dir != null) {
                            Box {
                                IconButton(onClick = { menuOpen = true }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "Меню")
                                }
                                DropdownMenu(
                                    expanded = menuOpen,
                                    onDismissRequest = { menuOpen = false }
                                ) {
                                    for (mode in SortMode.values()) {
                                        DropdownMenuItem(
                                            text = {
                                                Text(if (vm.sort == mode) "✓ ${mode.label}" else mode.label)
                                            },
                                            onClick = {
                                                menuOpen = false
                                                vm.setSort(mode)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (dir != null && vm.clipboard.isNotEmpty()) {
                Surface(color = cs.surface, tonalElevation = 3.dp) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            (if (vm.clipboardMove) "Переместить: " else "Копировать: ") +
                                vm.clipboard.size,
                            color = cs.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { vm.clearClipboard() }) { Text("Отмена") }
                        Button(onClick = {
                            vm.paste(dir) { n -> FileActions.toast(ctx, "Готово: $n") }
                        }) { Text("Вставить") }
                    }
                }
            }
        },
        floatingActionButton = {
            if (dir != null && !selecting) {
                FloatingActionButton(
                    onClick = { showNewFolder = true },
                    containerColor = cs.primary,
                    contentColor = cs.onPrimary
                ) {
                    Icon(Icons.Default.CreateNewFolder, contentDescription = "Новая папка")
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            val list = files
            when {
                list == null -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
                list.isEmpty() -> Text(
                    "Здесь пусто",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center)
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(list, key = { it.path }) { f ->
                        FileRow(
                            file = f,
                            selected = selected.contains(f),
                            selectionMode = selecting,
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    when {
                                        selecting -> toggle(f)
                                        f.isDirectory -> vm.navigate(Screen.Browser(f))
                                        else -> FileActions.open(ctx, f)
                                    }
                                },
                                onLongClick = { toggle(f) }
                            )
                        )
                    }
                }
            }
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Удалить выбранное?") },
            text = {
                Text(
                    "Элементов: ${selected.size}, размер: ${formatSize(selectedSize)}. " +
                        "Это действие нельзя отменить."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val toDelete = selected.toList()
                    selected.clear()
                    showDelete = false
                    vm.deleteFiles(toDelete) { n -> FileActions.toast(ctx, "Удалено: $n") }
                }) {
                    Text("Удалить", color = cs.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) { Text("Отмена") }
            }
        )
    }

    if (showRename && selected.size == 1) {
        val target = selected.first()
        InputDialog(
            title = "Переименовать",
            initial = target.name,
            confirmText = "OK",
            onConfirm = { name ->
                showRename = false
                val ok = vm.rename(target, name)
                FileActions.toast(ctx, if (ok) "Переименовано" else "Не удалось переименовать")
                selected.clear()
            },
            onDismiss = { showRename = false }
        )
    }

    if (showNewFolder && dir != null) {
        InputDialog(
            title = "Новая папка",
            initial = "",
            confirmText = "Создать",
            onConfirm = { name ->
                showNewFolder = false
                val ok = vm.createFolder(dir, name)
                FileActions.toast(ctx, if (ok) "Папка создана" else "Не удалось создать папку")
            },
            onDismiss = { showNewFolder = false }
        )
    }
}
