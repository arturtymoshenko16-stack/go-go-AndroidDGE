package com.filehub.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import com.filehub.app.MainViewModel
import com.filehub.app.Screen
import com.filehub.app.data.formatSize

@Composable
fun AppRoot(vm: MainViewModel) {
    val screen = vm.current
    key(screen) {
        when (screen) {
            Screen.Home -> HomeScreen(vm)
            Screen.Clean -> CleanScreen(vm)
            Screen.Settings -> SettingsScreen(vm)
            Screen.Search -> SearchScreen(vm)
            Screen.Large -> FilesScreen(
                vm = vm,
                title = "Крупные файлы",
                subtitle = vm.scan?.let { "от 10 МБ · всего ${formatSize(it.largeSize)}" },
                loader = { vm.scan?.large.orEmpty().filter { it.exists() } }
            )
            is Screen.Browser -> FilesScreen(
                vm = vm,
                title = if (screen.dir == vm.repo.root) "Внутренняя память" else screen.dir.name,
                subtitle = screen.dir.path,
                dir = screen.dir,
                loader = { vm.repo.list(screen.dir, vm.showHidden, vm.sort) }
            )
            is Screen.CategoryList -> FilesScreen(
                vm = vm,
                title = screen.category.label,
                loader = { vm.repo.filesOf(screen.category) }
            )
        }
    }
}
