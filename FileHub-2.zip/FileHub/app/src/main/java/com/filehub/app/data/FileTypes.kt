package com.filehub.app.data

import android.webkit.MimeTypeMap
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Category(val label: String) {
    APPS("Приложения"),
    IMAGES("Изображения"),
    VIDEOS("Видео"),
    MUSIC("Музыка"),
    DOCUMENTS("Документы"),
    OTHER("Прочее")
}

enum class SortMode(val label: String) {
    NAME("По имени"),
    SIZE("По размеру"),
    DATE("По дате")
}

object FileTypes {
    private val apps = setOf("apk", "xapk", "apks", "apkm")
    private val images = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")
    private val videos = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "m4v", "flv", "wmv")
    private val music = setOf("mp3", "wav", "flac", "aac", "ogg", "m4a", "opus", "wma", "amr")
    private val documents = setOf(
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf",
        "odt", "ods", "csv", "epub", "fb2", "md", "json", "xml", "html"
    )

    fun categoryOf(file: File): Category {
        return when (file.extension.lowercase(Locale.ROOT)) {
            in apps -> Category.APPS
            in images -> Category.IMAGES
            in videos -> Category.VIDEOS
            in music -> Category.MUSIC
            in documents -> Category.DOCUMENTS
            else -> Category.OTHER
        }
    }

    fun mimeOf(file: File): String {
        val ext = file.extension.lowercase(Locale.ROOT)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }
}

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes Б"
    val units = arrayOf("КБ", "МБ", "ГБ", "ТБ")
    var value = bytes.toDouble()
    var i = -1
    do {
        value /= 1024.0
        i++
    } while (value >= 1024.0 && i < units.lastIndex)
    val pattern = if (value >= 100) "%.0f %s" else "%.1f %s"
    return String.format(Locale.getDefault(), pattern, value, units[i])
}

fun formatDate(millis: Long): String {
    return SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(millis))
}
